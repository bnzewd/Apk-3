# احتفظ بأسماء الكلاسات الأساسية للحساسات والـ Activity
-keep class com.qibla.compass.** { *; }
-keep class androidx.constraintlayout.** { *; }
