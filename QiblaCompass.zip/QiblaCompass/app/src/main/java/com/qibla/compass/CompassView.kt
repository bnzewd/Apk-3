package com.qibla.compass

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * بوصلة بحركة سلسة ودقيقة.
 *
 * - Initial snap: عند أول رسم، القيم المعروضة تُساوي القيم الفعلية مباشرة
 *   (تجنّب قفزة دوران أولى من 0° إلى الموقع الفعلي)
 * - Adaptive smoothing: استجابة سريعة للحركات الكبيرة، نعومة للصغيرة
 * - Frame-based: مرتبط بمعدل الإطارات لا الحساس
 * - خط القبلة: ممتد من المركز للسهم كمساعد بصري للتوجّه
 * - تأثير Lock: إطار أخضر سميك + glow عند التوجيه الصحيح
 */
class CompassView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : View(context, attrs, defStyle) {

    var targetAzimuth: Float = 0f
        set(value) { field = value; postInvalidateOnAnimation() }

    var targetBearing: Float = 0f
        set(value) { field = value; postInvalidateOnAnimation() }

    var targetLabel: String = "القبلة"
        set(value) { field = value; postInvalidateOnAnimation() }

    var hasFix: Boolean = false
        set(value) {
            if (value && !field) shouldSnap = true  // أول fix → snap للقيم الفعلية
            field = value
            postInvalidateOnAnimation()
        }

    private var displayedAzimuth: Float = 0f
    private var displayedBearing: Float = 0f
    private var lastFrameTimeNanos: Long = 0L
    private var shouldSnap: Boolean = true  // ابدأ بـ snap لأول رسم

    private val FAST_RESPONSE = 18f
    private val SLOW_RESPONSE = 6f
    private val SETTLE_THRESHOLD = 0.05f

    val isLocked: Boolean
        get() = hasFix && abs(QiblaCalculator.shortestAngleDiff(
            targetAzimuth.toDouble(), targetBearing.toDouble()
        )) <= 2.0

    private fun adaptiveResponse(absDiff: Float): Float = when {
        absDiff >= 30f -> FAST_RESPONSE
        absDiff <= 2f -> SLOW_RESPONSE
        else -> {
            val t = (absDiff - 2f) / 28f
            SLOW_RESPONSE + t * (FAST_RESPONSE - SLOW_RESPONSE)
        }
    }

    // ───── الألوان والفُرَش ─────
    private val GOLD = Color.parseColor("#D4AF37")
    private val DARK = Color.parseColor("#1A1F2E")
    private val GREEN = Color.parseColor("#00C853")
    private val GREEN_DARK = Color.parseColor("#1B5E20")
    private val GREEN_LIGHT = Color.parseColor("#69F0AE")
    private val RED = Color.parseColor("#FF5252")
    private val WHITE = Color.parseColor("#FFFFFF")
    private val GREY = Color.parseColor("#9E9E9E")
    private val DIMMED = Color.parseColor("#404040")

    private val rosePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DARK; style = Paint.Style.FILL
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E0E0E0"); strokeWidth = 2f
    }
    private val majorTickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; strokeWidth = 5f
    }
    private val cardinalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = WHITE; textAlign = Paint.Align.CENTER
        isFakeBoldText = true; textSize = 40f
    }
    private val northPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = RED; textAlign = Paint.Align.CENTER
        isFakeBoldText = true; textSize = 46f
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREEN; style = Paint.Style.FILL
    }
    private val arrowStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREEN_DARK; style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val arrowDimmedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DIMMED; style = Paint.Style.FILL
    }
    private val centerLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; textAlign = Paint.Align.CENTER
        isFakeBoldText = true; textSize = 38f
    }
    private val degreePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREY; textAlign = Paint.Align.CENTER; textSize = 22f
    }
    private val kaabaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0A0A0A"); style = Paint.Style.FILL
    }
    private val kaabaBandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GOLD; style = Paint.Style.FILL
    }
    private val lockedRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREEN; style = Paint.Style.STROKE; strokeWidth = 12f
    }
    private val arrowGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5000C853"); style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL)
    }
    private val noFixPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = GREY; textAlign = Paint.Align.CENTER; textSize = 32f
    }

    // خط القبلة المتقطع (مساعد بصري للتوجّه)
    private val qiblaLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#80D4AF37")  // ذهبي شبه شفاف
        style = Paint.Style.STROKE
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(8f, 8f), 0f)
    }

    // إطار التوجيه الصحيح
    private val lockGlowOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4000C853")
        style = Paint.Style.STROKE
        strokeWidth = 24f
        maskFilter = BlurMaskFilter(20f, BlurMaskFilter.Blur.NORMAL)
    }

    // مؤشر دقة الزاوية - شريط بصري يبيّن قرب الزاوية الحالية للقبلة
    private val anglePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val angleBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1F404040")
        style = Paint.Style.FILL
    }
    private val angleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = WHITE; textAlign = Paint.Align.CENTER
        textSize = 22f; isFakeBoldText = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // ═════ Snap عند أول fix أو أول رسم: تجنّب دوران أولي مزعج ═════
        if (shouldSnap) {
            displayedAzimuth = targetAzimuth
            displayedBearing = targetBearing
            shouldSnap = false
        }

        // dt للإطار
        val now = System.nanoTime()
        val rawDt = if (lastFrameTimeNanos == 0L) 0.016f
                    else (now - lastFrameTimeNanos).toFloat() / 1_000_000_000f
        lastFrameTimeNanos = now
        val dt = rawDt.coerceIn(0.001f, 0.1f)

        val azDiff = shortestDiff(displayedAzimuth, targetAzimuth)
        val brDiff = shortestDiff(displayedBearing, targetBearing)

        val azResponse = adaptiveResponse(abs(azDiff))
        val brResponse = adaptiveResponse(abs(brDiff))

        val azT = (1f - exp(-azResponse * dt)).coerceIn(0f, 1f)
        val brT = (1f - exp(-brResponse * dt)).coerceIn(0f, 1f)

        displayedAzimuth = ((displayedAzimuth + azDiff * azT) + 360f) % 360f
        displayedBearing = ((displayedBearing + brDiff * brT) + 360f) % 360f

        drawCompass(canvas)

        if (abs(azDiff) > SETTLE_THRESHOLD || abs(brDiff) > SETTLE_THRESHOLD) {
            postInvalidateOnAnimation()
        }
    }

    private fun drawCompass(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(cx, cy) - 20f

        canvas.drawCircle(cx, cy, radius, rosePaint)

        // إطار التوجيه - أكثر بروزاً عند Lock
        if (isLocked) {
            // glow خارجي
            canvas.drawCircle(cx, cy, radius - 5f, lockGlowOuterPaint)
            canvas.drawCircle(cx, cy, radius, lockedRingPaint)
        } else {
            canvas.drawCircle(cx, cy, radius, ringPaint)
        }

        // وردة البوصلة - تدور عكس azimuth الجهاز
        canvas.save()
        canvas.rotate(-displayedAzimuth, cx, cy)
        drawRose(canvas, cx, cy, radius)
        canvas.restore()

        // السهم نحو الموقع المستهدف + خط القبلة
        if (hasFix) {
            canvas.save()
            canvas.rotate(displayedBearing - displayedAzimuth, cx, cy)

            if (!isLocked) {
                drawQiblaLine(canvas, cx, cy, radius)
            }

            drawArrow(canvas, cx, cy, radius)
            drawKaabaIcon(canvas, cx, cy - radius + 50f)
            canvas.restore()
            canvas.drawText(targetLabel, cx, cy + 12f, centerLabelPaint)

            // مؤشر دقة الزاوية - يظهر فقط عندما لم نصل للقبلة بعد
            // (عند Lock، السهم/الإطار الأخضر يكفي بصرياً)
            if (!isLocked) {
                drawAngleQuality(canvas, cx, cy + 65f, radius * 0.5f)
            }
        } else {
            drawWaitingState(canvas, cx, cy, radius)
        }
    }

    /**
     * مؤشر بصري لقرب الزاوية الحالية من الـ Qibla:
     * - أخضر: ≤ 1° (دقيق جداً)
     * - أصفر-أخضر: ≤ 3°
     * - برتقالي: ≤ 10°
     * - أحمر: > 10°
     */
    private fun drawAngleQuality(canvas: Canvas, cx: Float, cy: Float, halfWidth: Float) {
        val diff = abs(QiblaCalculator.shortestAngleDiff(
            displayedAzimuth.toDouble(), displayedBearing.toDouble()
        )).toFloat()

        val color = when {
            diff <= 1f -> Color.parseColor("#00C853")
            diff <= 3f -> Color.parseColor("#8BC34A")
            diff <= 10f -> Color.parseColor("#FFC107")
            else -> Color.parseColor("#FF5252")
        }

        val barH = 6f
        val maxFill = halfWidth * 2
        val normalizedDiff = (diff / 30f).coerceIn(0f, 1f)
        val fillW = maxFill * (1f - normalizedDiff)

        // النص فوق الشريط
        val text = when {
            diff <= 3f -> String.format("%.1f° عن القبلة", diff)
            diff <= 10f -> String.format("اقترب • %.1f°", diff)
            else -> String.format("%.0f° عن القبلة", diff)
        }
        angleTextPaint.color = color
        angleTextPaint.textSize = 20f
        canvas.drawText(text, cx, cy - 6f, angleTextPaint)

        // خلفية الشريط
        val bgRect = RectF(cx - halfWidth, cy + 4f, cx + halfWidth, cy + 4f + barH)
        canvas.drawRoundRect(bgRect, 3f, 3f, angleBgPaint)

        // الملء
        if (fillW > 0) {
            anglePaint.color = color
            val fillRect = RectF(
                cx - halfWidth, cy + 4f,
                cx - halfWidth + fillW, cy + 4f + barH
            )
            canvas.drawRoundRect(fillRect, 3f, 3f, anglePaint)
        }
    }

    /** خط متقطع من المركز نحو الهدف (مساعد بصري) */
    private fun drawQiblaLine(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        canvas.drawLine(
            cx, cy + radius * 0.35f,    // من قاعدة السهم
            cx, cy - radius + 75f,       // إلى رأس السهم
            qiblaLinePaint
        )
    }

    private fun drawWaitingState(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val path = Path().apply {
            moveTo(cx, cy - radius * 0.5f)
            lineTo(cx - 24f, cy - radius * 0.2f)
            lineTo(cx - 8f, cy - radius * 0.2f)
            lineTo(cx - 8f, cy + radius * 0.25f)
            lineTo(cx + 8f, cy + radius * 0.25f)
            lineTo(cx + 8f, cy - radius * 0.2f)
            lineTo(cx + 24f, cy - radius * 0.2f)
            close()
        }
        canvas.drawPath(path, arrowDimmedPaint)
        canvas.drawText("في انتظار GPS", cx, cy + radius * 0.5f, noFixPaint)
    }

    private fun drawRose(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        for (deg in 0 until 360 step 5) {
            val isMajor = deg % 30 == 0
            val isCardinal = deg % 90 == 0
            val len = when {
                isCardinal -> 36f
                isMajor -> 24f
                else -> 12f
            }
            val a = Math.toRadians((deg - 90).toDouble())
            val cosA = cos(a).toFloat()
            val sinA = sin(a).toFloat()
            val sx = cx + (radius - 10f) * cosA
            val sy = cy + (radius - 10f) * sinA
            val ex = cx + (radius - 10f - len) * cosA
            val ey = cy + (radius - 10f - len) * sinA
            canvas.drawLine(sx, sy, ex, ey, if (isMajor) majorTickPaint else tickPaint)

            if (isMajor && !isCardinal) {
                val tx = cx + (radius - 60f) * cosA
                val ty = cy + (radius - 60f) * sinA + 8f
                canvas.drawText(deg.toString(), tx, ty, degreePaint)
            }
        }

        drawCardinal(canvas, cx, cy, radius - 80f, 0, "شمال", northPaint)
        drawCardinal(canvas, cx, cy, radius - 80f, 90, "شرق", cardinalPaint)
        drawCardinal(canvas, cx, cy, radius - 80f, 180, "جنوب", cardinalPaint)
        drawCardinal(canvas, cx, cy, radius - 80f, 270, "غرب", cardinalPaint)
    }

    private fun drawCardinal(
        canvas: Canvas, cx: Float, cy: Float,
        radius: Float, deg: Int, text: String, paint: Paint
    ) {
        val a = Math.toRadians((deg - 90).toDouble())
        val tx = cx + radius * cos(a).toFloat()
        val ty = cy + radius * sin(a).toFloat() + paint.textSize / 3
        canvas.drawText(text, tx, ty, paint)
    }

    private fun drawArrow(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        val tipY = cy - radius + 80f
        val baseY = cy - radius * 0.4f
        val w = 32f
        val tailY = cy + radius * 0.35f

        val path = Path().apply {
            moveTo(cx, tipY)
            lineTo(cx - w, baseY)
            lineTo(cx - 10f, baseY - 6f)
            lineTo(cx - 10f, tailY)
            lineTo(cx + 10f, tailY)
            lineTo(cx + 10f, baseY - 6f)
            lineTo(cx + w, baseY)
            close()
        }

        if (isLocked) canvas.drawPath(path, arrowGlowPaint)
        canvas.drawPath(path, arrowPaint)
        canvas.drawPath(path, arrowStrokePaint)

        canvas.drawCircle(cx, tailY, 12f, arrowPaint)
        canvas.drawCircle(cx, tailY, 12f, arrowStrokePaint)
    }

    private fun drawKaabaIcon(canvas: Canvas, cx: Float, cy: Float) {
        val size = 28f
        val rect = RectF(cx - size, cy - size, cx + size, cy + size)
        canvas.drawRect(rect, kaabaPaint)
        val band = RectF(cx - size, cy - size * 0.25f, cx + size, cy + size * 0.05f)
        canvas.drawRect(band, kaabaBandPaint)
        canvas.drawRect(rect, ringPaint)
    }

    private fun shortestDiff(from: Float, to: Float): Float {
        var d = (to - from) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }
}
