package com.qibla.compass

import android.app.Application

class QiblaApp : Application()
