package com.qibla.compass

import kotlin.math.sqrt

/**
 * فلتر Kalman لإحداثيات GPS مع process noise تكيّفي.
 *
 * المبدأ: process noise يمثل "كم نتوقع أن يتحرك المستخدم بين قراءتين".
 * - ثابت 3 m/s = افتراض المشي → غير مثالي عند الوقوف أو السرعة العالية
 * - تكيّفي حسب `loc.speed` = أمثل في كل الحالات
 *
 * عند الوقوف (speed < 0.3 m/s):
 *   processNoise → 0.5 m/s (Kalman يثق في حالته الداخلية → دقة أعلى)
 *
 * عند الحركة:
 *   processNoise → max(speed × 1.5, 0.5) m/s
 *   (يسمح بتغيير الموقع بسرعة المستخدم الفعلية)
 *
 * هذا يعطي:
 * - دقة أعلى عند الوقوف (التطبيق الأساسي)
 * - استجابة سريعة عند الحركة (سيارة، مشي)
 */
class LocationKalmanFilter(
    /** القيمة الافتراضية إذا السرعة غير معروفة */
    private val defaultProcessNoiseMs: Float = 3f
) {

    private var lat: Double = 0.0
    private var lon: Double = 0.0
    private var variance: Float = -1f
    private var lastTimestampMs: Long = 0L

    /**
     * معالجة قراءة GPS جديدة، إرجاع الإحداثيات المنعّمة.
     *
     * @param speedMs السرعة بالمتر/ثانية. مرّر -1 إذا غير معروفة.
     */
    fun process(
        latMeasurement: Double,
        lonMeasurement: Double,
        accuracyM: Float,
        timestampMs: Long,
        speedMs: Float = -1f
    ): Pair<Double, Double> {

        if (variance < 0f) {
            lat = latMeasurement
            lon = lonMeasurement
            variance = accuracyM * accuracyM
            lastTimestampMs = timestampMs
            return Pair(lat, lon)
        }

        // ════ Process noise التكيّفي ════
        val adaptivePN = when {
            speedMs in 0f..0.3f -> 0.5f                          // وقوف → ثقة عالية بالحالة
            speedMs > 0.3f -> (speedMs * 1.5f).coerceAtLeast(0.5f)  // حركة → اتبع السرعة
            else -> defaultProcessNoiseMs                          // غير معروف
        }

        // مرحلة التنبؤ
        val dtSec = (timestampMs - lastTimestampMs).toFloat() / 1000f
        if (dtSec > 0) {
            variance += dtSec * adaptivePN * adaptivePN
            lastTimestampMs = timestampMs
        }

        // مرحلة التحديث
        val measurementVariance = accuracyM * accuracyM
        val k = variance / (variance + measurementVariance)

        lat += k * (latMeasurement - lat)
        lon += k * (lonMeasurement - lon)
        variance *= (1f - k)

        return Pair(lat, lon)
    }

    val effectiveAccuracy: Float
        get() = if (variance < 0f) Float.POSITIVE_INFINITY else sqrt(variance)

    fun reset() {
        variance = -1f
        lastTimestampMs = 0L
    }
}
