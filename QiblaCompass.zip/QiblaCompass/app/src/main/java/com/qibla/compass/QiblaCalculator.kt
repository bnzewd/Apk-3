package com.qibla.compass

import kotlin.math.*

/**
 * حسابات اتجاه القبلة بدقة عالية - بدون انترنت.
 *
 * يقدم خوارزميتين:
 * 1. Great Circle (Haversine) - بسيط وسريع، دقة ممتازة على نموذج كروي
 * 2. Vincenty - أدق، يأخذ في الاعتبار شكل الأرض البيضاوي (WGS84 ellipsoid)
 *
 * الفرق بينهما عملياً < 0.5° لاتجاه القبلة من أي مكان على الأرض.
 * Vincenty مهم للمسافات (دقة ~مم) لكن للزاوية، Haversine كافٍ.
 *
 * نستخدم Vincenty للمسافة وGreat Circle للزاوية (الأفضل من كلا).
 */
object QiblaCalculator {

    // ثوابت WGS84 (نموذج الأرض المعتمد للـ GPS)
    private const val WGS84_A = 6378137.0           // نصف القطر الاستوائي بالمتر
    private const val WGS84_B = 6356752.314245      // نصف القطر القطبي بالمتر
    private const val WGS84_F = 1.0 / 298.257223563 // التفلطح

    private const val EARTH_RADIUS_KM = 6371.0088   // متوسط نصف قطر الأرض

    /**
     * زاوية القبلة الأولية من المستخدم نحو الموقع.
     * صيغة Great Circle initial bearing على كرة (الأكثر اعتماداً فقهياً).
     *
     * θ = atan2( sin(Δλ)·cos(φ₂), cos(φ₁)·sin(φ₂) − sin(φ₁)·cos(φ₂)·cos(Δλ) )
     */
    fun bearingTo(
        userLat: Double, userLon: Double,
        targetLat: Double, targetLon: Double
    ): Double {
        val φ1 = Math.toRadians(userLat)
        val φ2 = Math.toRadians(targetLat)
        val Δλ = Math.toRadians(targetLon - userLon)

        val y = sin(Δλ) * cos(φ2)
        val x = cos(φ1) * sin(φ2) - sin(φ1) * cos(φ2) * cos(Δλ)

        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    /**
     * المسافة بالكيلومتر باستخدام Vincenty على بيضوي WGS84.
     * أدق من Haversine بـ ~0.5%، خاصة للمسافات الطويلة.
     * في حال عدم التقارب (نقطتان متقابلتان قطرياً)، يقع على Haversine.
     */
    fun distanceKm(
        userLat: Double, userLon: Double,
        targetLat: Double, targetLon: Double
    ): Double {
        val a = WGS84_A
        val b = WGS84_B
        val f = WGS84_F

        val L = Math.toRadians(targetLon - userLon)
        val U1 = atan((1 - f) * tan(Math.toRadians(userLat)))
        val U2 = atan((1 - f) * tan(Math.toRadians(targetLat)))
        val sinU1 = sin(U1); val cosU1 = cos(U1)
        val sinU2 = sin(U2); val cosU2 = cos(U2)

        var lambda = L
        var lambdaP: Double
        var iterLimit = 100
        var sinLambda: Double; var cosLambda: Double
        var sinSigma: Double; var cosSigma: Double; var sigma: Double
        var sinAlpha: Double; var cosSqAlpha: Double; var cos2SigmaM: Double; var c: Double

        do {
            sinLambda = sin(lambda); cosLambda = cos(lambda)
            sinSigma = sqrt(
                (cosU2 * sinLambda).pow(2.0) +
                (cosU1 * sinU2 - sinU1 * cosU2 * cosLambda).pow(2.0)
            )
            if (sinSigma == 0.0) return 0.0

            cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosLambda
            sigma = atan2(sinSigma, cosSigma)
            sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma
            cosSqAlpha = 1 - sinAlpha * sinAlpha
            cos2SigmaM = if (cosSqAlpha == 0.0) 0.0
                         else cosSigma - 2 * sinU1 * sinU2 / cosSqAlpha
            c = f / 16 * cosSqAlpha * (4 + f * (4 - 3 * cosSqAlpha))
            lambdaP = lambda
            lambda = L + (1 - c) * f * sinAlpha *
                    (sigma + c * sinSigma *
                            (cos2SigmaM + c * cosSigma *
                                    (-1 + 2 * cos2SigmaM * cos2SigmaM)))
            iterLimit--
        } while (abs(lambda - lambdaP) > 1e-12 && iterLimit > 0)

        if (iterLimit == 0) {
            // fallback: Haversine
            return haversineKm(userLat, userLon, targetLat, targetLon)
        }

        val uSq = cosSqAlpha * (a * a - b * b) / (b * b)
        val A = 1 + uSq / 16384 *
                (4096 + uSq * (-768 + uSq * (320 - 175 * uSq)))
        val B = uSq / 1024 *
                (256 + uSq * (-128 + uSq * (74 - 47 * uSq)))
        val deltaSigma = B * sinSigma *
                (cos2SigmaM + B / 4 *
                        (cosSigma * (-1 + 2 * cos2SigmaM * cos2SigmaM) -
                                B / 6 * cos2SigmaM *
                                (-3 + 4 * sinSigma * sinSigma) *
                                (-3 + 4 * cos2SigmaM * cos2SigmaM)))
        val s = b * A * (sigma - deltaSigma)
        return s / 1000.0  // متر إلى كم
    }

    /** Haversine بسيط (احتياطي + للمسافات القصيرة) */
    private fun haversineKm(
        userLat: Double, userLon: Double,
        targetLat: Double, targetLon: Double
    ): Double {
        val φ1 = Math.toRadians(userLat)
        val φ2 = Math.toRadians(targetLat)
        val Δφ = Math.toRadians(targetLat - userLat)
        val Δλ = Math.toRadians(targetLon - userLon)
        val a = sin(Δφ / 2).pow(2.0) + cos(φ1) * cos(φ2) * sin(Δλ / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_KM * c
    }

    /** أصغر فرق زاوي بين زاويتين (-180..+180) */
    fun shortestAngleDiff(from: Double, to: Double): Double {
        var d = (to - from) % 360.0
        if (d > 180.0) d -= 360.0
        if (d < -180.0) d += 360.0
        return d
    }

    /** زاوية إلى نص اتجاه عربي (٨ جهات) */
    fun cardinalAr(degrees: Double): String {
        val dirs = arrayOf(
            "شمال", "شمال شرق", "شرق", "جنوب شرق",
            "جنوب", "جنوب غرب", "غرب", "شمال غرب"
        )
        val idx = (((degrees + 22.5) / 45.0).toInt() % 8 + 8) % 8
        return dirs[idx]
    }

    /**
     * تنسيق الزاوية بصيغة دقائق وثوان (DMS).
     * مثال: 245.123° → "245° 7' 23""
     */
    fun formatDMS(degrees: Double): String {
        val absDeg = abs(degrees)
        val d = absDeg.toInt()
        val mFloat = (absDeg - d) * 60.0
        val m = mFloat.toInt()
        val s = ((mFloat - m) * 60.0).toInt()
        return "$d° $m' $s\""
    }

    /**
     * تنسيق المسافة بدقة مناسبة:
     * < 1 كم  → بالأمتار
     * < 10 كم → بدقة عشريتين
     * < 100 كم → بدقة عشرة واحدة
     * أكبر    → بدون كسور مع فاصلة آلاف
     */
    fun formatDistance(km: Double): String = when {
        km < 1.0 -> String.format("%.0f م", km * 1000)
        km < 10.0 -> String.format("%.2f كم", km)
        km < 100.0 -> String.format("%.1f كم", km)
        else -> String.format("%,.0f كم", km)
    }
}
