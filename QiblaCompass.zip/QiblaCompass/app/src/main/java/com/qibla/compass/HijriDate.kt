package com.qibla.compass

import kotlin.math.floor

/**
 * تحويل التاريخ الميلادي إلى الهجري (التقويم الإسلامي الجدولي)
 * يعمل بدون انترنت. ملاحظة: التقويم الفعلي يعتمد على رؤية الهلال
 * وقد يختلف بيوم أو يومين عن هذا التقريب.
 */
object HijriDate {

    private val MONTHS_AR = arrayOf(
        "محرّم", "صفر", "ربيع الأول", "ربيع الثاني",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوّال", "ذو القعدة", "ذو الحجة"
    )

    /** يحوّل تاريخاً ميلادياً إلى ثلاثية هجرية (سنة، شهر 1-12، يوم) */
    fun fromGregorian(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val jd = gregorianToJD(gy, gm, gd)
        return jdToHijri(jd)
    }

    /** صيغة عربية كاملة: "١٥ شعبان ١٤٤٧ هـ" */
    fun formatAr(gy: Int, gm: Int, gd: Int): String {
        val (y, m, d) = fromGregorian(gy, gm, gd)
        return "$d ${MONTHS_AR[m - 1]} $y هـ"
    }

    private fun gregorianToJD(y: Int, m: Int, d: Int): Long {
        var year = y; var month = m
        if (month <= 2) { year--; month += 12 }
        val A = year / 100
        val B = 2 - A + A / 4
        return (floor(365.25 * (year + 4716)) +
                floor(30.6001 * (month + 1)) +
                d + B - 1524).toLong()
    }

    private fun jdToHijri(jd: Long): Triple<Int, Int, Int> {
        val l = jd - 1948440 + 10632
        val n = (l - 1) / 10631
        val l2 = l - 10631 * n + 354
        val j = ((10985 - l2) / 5316) * ((50 * l2) / 17719) +
                (l2 / 5670) * ((43 * l2) / 15238)
        val l3 = l2 - ((30 - j) / 15) * ((17719 * j) / 50) -
                (j / 16) * ((15238 * j) / 43) + 29
        val month = ((24 * l3) / 709).toInt()
        val day = (l3 - (709 * month) / 24).toInt()
        val year = (30 * n + j - 30).toInt()
        return Triple(year, month, day)
    }
}
