package com.qibla.compass

import android.content.Context
import android.content.SharedPreferences

/**
 * تخزين محلي دائم - لا يحتاج إنترنت
 * يحفظ:
 * - آخر موقع GPS معروف (ليفتح التطبيق ويعمل فوراً)
 * - آخر مزار مختار (لتجربة مستخدم متسقة)
 */
class Preferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("qibla_compass", Context.MODE_PRIVATE)

    // ───── آخر موقع محفوظ ─────

    data class SavedLocation(
        val latitude: Double,
        val longitude: Double,
        val altitude: Double,
        val accuracy: Float,
        val savedAtMs: Long
    ) {
        /** هل الموقع المحفوظ صالح للاستخدام كنقطة بداية؟ */
        val isUsable: Boolean
            get() = !latitude.isNaN() && !longitude.isNaN() &&
                    latitude in -90.0..90.0 &&
                    longitude in -180.0..180.0 &&
                    accuracy > 0f && accuracy < 10000f

        /** عمر الموقع المحفوظ بالساعات */
        val ageHours: Double
            get() = (System.currentTimeMillis() - savedAtMs) / 3_600_000.0
    }

    fun saveLocation(lat: Double, lon: Double, alt: Double, accuracy: Float) {
        prefs.edit().apply {
            putLong("loc_lat", java.lang.Double.doubleToRawLongBits(lat))
            putLong("loc_lon", java.lang.Double.doubleToRawLongBits(lon))
            putLong("loc_alt", java.lang.Double.doubleToRawLongBits(alt))
            putFloat("loc_acc", accuracy)
            putLong("loc_time", System.currentTimeMillis())
            apply()
        }
    }

    fun loadLocation(): SavedLocation? {
        if (!prefs.contains("loc_lat")) return null
        val lat = java.lang.Double.longBitsToDouble(
            prefs.getLong("loc_lat", java.lang.Double.doubleToRawLongBits(Double.NaN))
        )
        val lon = java.lang.Double.longBitsToDouble(
            prefs.getLong("loc_lon", java.lang.Double.doubleToRawLongBits(Double.NaN))
        )
        val alt = java.lang.Double.longBitsToDouble(
            prefs.getLong("loc_alt", java.lang.Double.doubleToRawLongBits(0.0))
        )
        val acc = prefs.getFloat("loc_acc", -1f)
        val time = prefs.getLong("loc_time", 0L)
        if (lat.isNaN() || lon.isNaN() || time == 0L) return null
        val saved = SavedLocation(lat, lon, alt, acc, time)
        return if (saved.isUsable) saved else null
    }

    // ───── آخر مزار مختار ─────

    var selectedTargetId: String
        get() = prefs.getString("target_id", HolyLocations.KAABA.id) ?: HolyLocations.KAABA.id
        set(value) { prefs.edit().putString("target_id", value).apply() }
}
