package com.qibla.compass

import android.location.Location
import kotlin.math.sqrt

/**
 * متوسط موزون للإحداثيات عند الوقوف الثابت.
 *
 * المبدأ الإحصائي: متوسط N قراءة مستقلة لكل منها σ يعطي متوسطاً بدقة σ/√N.
 * نستخدم المتوسط الموزون (الوزن = 1/σ²) لإعطاء وزن أعلى للقراءات الأدق.
 *
 * مثال:
 * - 30 قراءة بدقة ±10م → دقة فعّالة ~1.8م
 * - 60 قراءة → ~1.3م
 *
 * يدعم:
 * - رفض الـ outliers الفردية (قراءة واحدة شاذة)
 * - الاستجابة للحركة الفعلية (3+ outliers متتالية → إعادة تهيئة)
 * - فجوات زمنية (>5 ث → إعادة تهيئة)
 */
class StationaryAverager(private val maxSamples: Int = 30) {

    private data class Sample(
        val lat: Double,
        val lon: Double,
        val accuracy: Float,
        val timeMs: Long
    )

    private val samples = ArrayDeque<Sample>()
    private var consecutiveOutliers: Int = 0

    companion object {
        private const val OUTLIER_SIGMA_FACTOR = 3.0f
        private const val MAX_CONSECUTIVE_OUTLIERS = 3
        private const val MAX_GAP_MS = 5000L
    }

    /** أضف قراءة جديدة */
    fun add(loc: Location) {
        // تجاهل القراءات السيئة
        if (loc.accuracy <= 0f || loc.accuracy > 100f) return

        // فجوة زمنية كبيرة → الجلسة انقطعت، أعد التهيئة
        if (samples.isNotEmpty() && loc.time - samples.last().timeMs > MAX_GAP_MS) {
            samples.clear()
            consecutiveOutliers = 0
        }

        // فحص outlier (يحتاج 5+ عينات سابقة)
        if (samples.size >= 5) {
            val mean = computeWeightedMean()
            if (mean != null) {
                val deltaM = approximateDistanceM(
                    loc.latitude, loc.longitude,
                    mean.latitude, mean.longitude
                )
                val tolerance = (mean.accuracyM + loc.accuracy) * OUTLIER_SIGMA_FACTOR
                if (deltaM > tolerance) {
                    // قراءة بعيدة - عدها outlier
                    consecutiveOutliers++
                    if (consecutiveOutliers >= MAX_CONSECUTIVE_OUTLIERS) {
                        // ٣ outliers متتالية = المستخدم تحرك فعلاً
                        // أعد التهيئة بدلاً من البقاء على الموقع القديم
                        samples.clear()
                        consecutiveOutliers = 0
                        samples.addLast(Sample(loc.latitude, loc.longitude, loc.accuracy, loc.time))
                    }
                    return
                }
            }
        }

        // قراءة طبيعية - أضِف
        consecutiveOutliers = 0
        samples.addLast(Sample(loc.latitude, loc.longitude, loc.accuracy, loc.time))
        while (samples.size > maxSamples) samples.removeFirst()
    }

    /** فرّغ الذاكرة (استدعِ عند بدء الحركة) */
    fun reset() {
        samples.clear()
        consecutiveOutliers = 0
    }

    /** عدد العينات المُجمَّعة حالياً */
    val sampleCount: Int get() = samples.size

    /**
     * احسب المتوسط الموزون لجميع العينات الحالية.
     * يعود null إذا لم يكن هناك ما يكفي من العينات (≥3).
     */
    fun computeWeightedMean(): Result? {
        if (samples.size < 3) return null

        var sumWeight = 0.0
        var sumLat = 0.0
        var sumLon = 0.0
        for (s in samples) {
            val variance = s.accuracy.toDouble() * s.accuracy
            val weight = 1.0 / variance
            sumWeight += weight
            sumLat += s.lat * weight
            sumLon += s.lon * weight
        }
        val avgLat = sumLat / sumWeight
        val avgLon = sumLon / sumWeight
        val effectiveAccuracy = sqrt(1.0 / sumWeight).toFloat()

        return Result(avgLat, avgLon, effectiveAccuracy, samples.size)
    }

    data class Result(
        val latitude: Double,
        val longitude: Double,
        val accuracyM: Float,
        val sampleCount: Int
    )

    /** تقريب سريع للمسافة بالأمتار (للمسافات الصغيرة فقط) */
    private fun approximateDistanceM(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Float {
        val dLat = (lat2 - lat1) * 111320.0
        val dLon = (lon2 - lon1) * 111320.0 * Math.cos(Math.toRadians(lat1))
        return sqrt(dLat * dLat + dLon * dLon).toFloat()
    }
}
