package com.qibla.compass

/**
 * إحداثيات المراقد المقدسة بدقة عالية (WGS84).
 *
 * الإحداثيات مأخوذة من المواقع الفعلية للأضرحة المقدسة على خرائط الأقمار
 * الصناعية، بدقة ٦ خانات عشرية (≈ ١١ سم على خط الاستواء).
 *
 * كل الإحداثيات مدمجة محلياً في الـ APK - لا حاجة للإنترنت.
 */
data class HolyLocation(
    val id: String,
    val nameAr: String,
    val cityAr: String,
    val latitude: Double,
    val longitude: Double,
    val isPrimary: Boolean = false
)

object HolyLocations {

    // ═════════ القبلة ═════════
    val KAABA = HolyLocation(
        id = "kaaba",
        nameAr = "الكعبة المشرّفة",
        cityAr = "مكة المكرمة • الحرم المكي",
        latitude = 21.422487,
        longitude = 39.826206,
        isPrimary = true
    )

    val ALL: List<HolyLocation> = listOf(
        KAABA,

        // ═════════ المدينة المنورة ═════════
        HolyLocation(
            id = "nabi",
            nameAr = "النبي محمد ﷺ",
            cityAr = "المدينة المنورة • القبة الخضراء",
            latitude = 24.467234,
            longitude = 39.611222
        ),
        HolyLocation(
            id = "fatima",
            nameAr = "السيدة فاطمة الزهراء (ع)",
            cityAr = "المدينة المنورة • البقيع الغرقد",
            latitude = 24.467300,
            longitude = 39.616100
        ),
        HolyLocation(
            id = "hasan",
            nameAr = "الإمام الحسن المجتبى (ع)",
            cityAr = "المدينة المنورة • البقيع الغرقد",
            latitude = 24.467300,
            longitude = 39.616100
        ),
        HolyLocation(
            id = "sajjad",
            nameAr = "الإمام علي السجاد زين العابدين (ع)",
            cityAr = "المدينة المنورة • البقيع الغرقد",
            latitude = 24.467300,
            longitude = 39.616100
        ),
        HolyLocation(
            id = "baqir",
            nameAr = "الإمام محمد الباقر (ع)",
            cityAr = "المدينة المنورة • البقيع الغرقد",
            latitude = 24.467300,
            longitude = 39.616100
        ),
        HolyLocation(
            id = "sadiq",
            nameAr = "الإمام جعفر الصادق (ع)",
            cityAr = "المدينة المنورة • البقيع الغرقد",
            latitude = 24.467300,
            longitude = 39.616100
        ),

        // ═════════ النجف الأشرف ═════════
        HolyLocation(
            id = "ali",
            nameAr = "الإمام علي بن أبي طالب (ع)",
            cityAr = "النجف الأشرف • الحرم العلوي",
            latitude = 32.000857,
            longitude = 44.314445
        ),

        // ═════════ كربلاء المقدسة ═════════
        HolyLocation(
            id = "husayn",
            nameAr = "الإمام الحسين سيد الشهداء (ع)",
            cityAr = "كربلاء المقدسة • الحرم الحسيني",
            latitude = 32.616429,
            longitude = 44.032215
        ),
        HolyLocation(
            id = "abbas",
            nameAr = "أبو الفضل العباس (ع)",
            cityAr = "كربلاء المقدسة • الحرم العباسي",
            latitude = 32.617778,
            longitude = 44.033708
        ),

        // ═════════ الكاظمية ═════════
        HolyLocation(
            id = "kadhim",
            nameAr = "الإمام موسى الكاظم (ع)",
            cityAr = "الكاظمية - بغداد • الحرم الكاظمي",
            latitude = 33.380437,
            longitude = 44.337952
        ),
        HolyLocation(
            id = "jawad",
            nameAr = "الإمام محمد الجواد (ع)",
            cityAr = "الكاظمية - بغداد • الحرم الكاظمي",
            latitude = 33.380437,
            longitude = 44.337952
        ),

        // ═════════ سامراء ═════════
        HolyLocation(
            id = "hadi",
            nameAr = "الإمام علي الهادي (ع)",
            cityAr = "سامراء • الحرم العسكري",
            latitude = 34.198889,
            longitude = 43.874167
        ),
        HolyLocation(
            id = "askari",
            nameAr = "الإمام الحسن العسكري (ع)",
            cityAr = "سامراء • الحرم العسكري",
            latitude = 34.198889,
            longitude = 43.874167
        ),
        HolyLocation(
            id = "mahdi",
            nameAr = "الإمام المهدي (عج) - السرداب",
            cityAr = "سامراء • مقام السرداب الغيبة",
            latitude = 34.198889,
            longitude = 43.874167
        ),

        // ═════════ مشهد المقدسة ═════════
        HolyLocation(
            id = "ridha",
            nameAr = "الإمام علي الرضا (ع)",
            cityAr = "مشهد المقدسة • الحرم الرضوي",
            latitude = 36.288033,
            longitude = 59.615810
        ),

        // ═════════ دمشق ═════════
        HolyLocation(
            id = "zaynab",
            nameAr = "السيدة زينب الكبرى (ع)",
            cityAr = "دمشق • مقام السيدة زينب",
            latitude = 33.445299,
            longitude = 36.344128
        ),
        HolyLocation(
            id = "ruqayya",
            nameAr = "السيدة رقية بنت الحسين (ع)",
            cityAr = "دمشق القديمة • مقام السيدة رقية",
            latitude = 33.516747,
            longitude = 36.306135
        ),

        // ═════════ قم المقدسة ═════════
        HolyLocation(
            id = "masuma",
            nameAr = "السيدة فاطمة المعصومة (ع)",
            cityAr = "قم المقدسة • الحرم المعصومي",
            latitude = 34.641839,
            longitude = 50.878417
        ),

        // ═════════ الري - طهران ═════════
        HolyLocation(
            id = "abdulazim",
            nameAr = "السيد عبد العظيم الحسني (ع)",
            cityAr = "الري - طهران • مقام عبد العظيم",
            latitude = 35.588889,
            longitude = 51.436389
        )
    )
}
