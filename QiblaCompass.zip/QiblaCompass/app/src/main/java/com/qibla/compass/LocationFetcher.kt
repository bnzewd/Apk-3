package com.qibla.compass

import android.annotation.SuppressLint
import android.content.Context
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * مدير الموقع الذكي - GPS hardware فقط.
 *
 * الحماية متعددة الطبقات ضد القراءات السيئة:
 * 1. تصفية أساسية (NaN, خارج المدى, accuracy غير معقول)
 * 2. فلتر القفزات: يرفض الحركة الأسرع من 100 م/ث
 * 3. فلتر Kalman: يدمج عدة قراءات إحصائياً
 * 4. حفظ القراءات الجيدة فقط (< 30م) في الكاش
 */
class LocationFetcher(private val context: Context) {

    enum class Quality {
        EXCELLENT,   // ≤ 5م
        VERY_GOOD,   // ≤ 10م
        GOOD,        // ≤ 20م
        ACCEPTABLE,  // ≤ 50م
        POOR         // > 50م
    }

    sealed class Update {
        data class Fix(
            val location: Location,
            val rawAccuracyM: Float,
            val effectiveAccuracyM: Float,
            val quality: Quality,
            val satellitesUsed: Int,
            val satellitesVisible: Int,
            val hasMultiFrequencyGps: Boolean = false,
            val isFromCache: Boolean = false,
            val reliabilityScore: Int = 0,
            val constellations: Set<Int> = emptySet(),  // GPS, GLONASS, Galileo, ...
            val averageSnrDbHz: Float = 0f  // متوسط قوة إشارة الأقمار المستخدمة
        ) : Update()

        data class Searching(
            val elapsedSec: Long,
            val satellitesVisible: Int,
            val cachedLocation: Preferences.SavedLocation? = null
        ) : Update()

        object GpsDisabled : Update()
        object NoPermission : Update()
        object MockLocationDetected : Update()  // تم رصد موقع وهمي
    }

    private val prefs = Preferences(context)

    @SuppressLint("MissingPermission")
    fun updates(): Flow<Update> = callbackFlow {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val kalman = LocationKalmanFilter(defaultProcessNoiseMs = 3f)

        // ───── البداية الفورية: الكاش المحلي ─────
        val cached = prefs.loadLocation()
        if (cached != null && cached.ageHours < 24.0) {
            val cachedLoc = Location("cached").apply {
                latitude = cached.latitude
                longitude = cached.longitude
                if (cached.altitude != 0.0) altitude = cached.altitude
                accuracy = cached.accuracy.coerceAtLeast(50f)
                time = cached.savedAtMs
            }
            trySend(Update.Fix(
                location = cachedLoc,
                rawAccuracyM = cached.accuracy,
                effectiveAccuracyM = cached.accuracy,
                quality = qualityOf(cached.accuracy),
                satellitesUsed = 0,
                satellitesVisible = 0,
                isFromCache = true
            ))
        }

        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            trySend(Update.GpsDisabled)
            close()
            return@callbackFlow
        }

        var bestLocation: Location? = null
        var lastAcceptedRaw: Location? = null
        var lastFix: Update.Fix? = null
        var satellitesVisible = 0
        var satellitesUsed = 0
        var hasL5 = false
        var constellations = emptySet<Int>()
        var avgSnr = 0f
        val startTime = SystemClock.elapsedRealtime()
        val handler = Handler(Looper.getMainLooper())

        fun publishKalmanFix(loc: Location) {
            // مرّر السرعة الفعلية لـ Kalman (إذا متاحة) لـ adaptive process noise
            val speedForKalman = if (loc.hasSpeed()) loc.speed else -1f
            val (smoothLat, smoothLon) = kalman.process(
                loc.latitude, loc.longitude, loc.accuracy, loc.time, speedForKalman
            )
            val effectiveAcc = kalman.effectiveAccuracy.coerceAtMost(loc.accuracy)

            val smoothed = Location(loc).apply {
                latitude = smoothLat
                longitude = smoothLon
                accuracy = effectiveAcc
            }

            // احفظ فقط القراءات الممتازة (< 30م خام) في الكاش
            if (loc.accuracy < 30f) {
                prefs.saveLocation(
                    smoothLat, smoothLon,
                    if (loc.hasAltitude()) loc.altitude else 0.0,
                    effectiveAcc
                )
            }

            // عمر fix - نستخدم elapsedRealtimeNanos (مونوتوني، آمن من تغيير ساعة النظام)
            val fixAgeMs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                (SystemClock.elapsedRealtimeNanos() - loc.elapsedRealtimeNanos) / 1_000_000
            } else {
                System.currentTimeMillis() - loc.time
            }
            val reliability = computeReliabilityScore(
                effectiveAcc, satellitesUsed, hasL5, fixAgeMs
            )

            val fix = Update.Fix(
                location = smoothed,
                rawAccuracyM = loc.accuracy,
                effectiveAccuracyM = effectiveAcc,
                quality = qualityOf(effectiveAcc),
                satellitesUsed = satellitesUsed,
                satellitesVisible = satellitesVisible,
                hasMultiFrequencyGps = hasL5,
                isFromCache = false,
                reliabilityScore = reliability,
                constellations = constellations,
                averageSnrDbHz = avgSnr
            )
            lastFix = fix
            trySend(fix)
        }

        // ───── مستمع الموقع ─────
        val locListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (!location.isValid()) return

                // ════ كشف المواقع الوهمية - رفض كامل ════
                // تطبيقات الـ mock location قد تزيف الموقع لأسباب مختلفة
                // التطبيق يرفضها لضمان دقة اتجاه القبلة
                if (location.isMockProvider()) {
                    trySend(Update.MockLocationDetected)
                    return
                }

                // فحص القفزات: ارفض الحركة الأسرع من 100 م/ث
                val prev = lastAcceptedRaw
                if (prev != null && isImpossibleJump(prev, location)) {
                    return
                }

                val current = bestLocation
                val take = when {
                    current == null -> true
                    location.accuracy <= current.accuracy + 5f -> true
                    SystemClock.elapsedRealtimeNanos() / 1_000_000 -
                        current.elapsedRealtimeNanos / 1_000_000 > 15_000 -> true
                    else -> false
                }
                if (!take) return

                bestLocation = location
                lastAcceptedRaw = location
                publishKalmanFix(location)
            }

            @Deprecated("Required for older Android versions")
            override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {
                if (p == LocationManager.GPS_PROVIDER) {
                    trySend(Update.GpsDisabled)
                }
            }
        }

        // ───── مستمع الأقمار ─────
        val gnssCallback = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            object : GnssStatus.Callback() {
                override fun onSatelliteStatusChanged(status: GnssStatus) {
                    satellitesVisible = status.satelliteCount
                    var used = 0
                    var l5Detected = false
                    val constellationSet = mutableSetOf<Int>()
                    var snrSum = 0f
                    var snrCount = 0

                    for (i in 0 until status.satelliteCount) {
                        if (status.usedInFix(i)) {
                            used++

                            // ════ كشف الكوكبة (GPS, GLONASS, Galileo, ...) ════
                            constellationSet.add(status.getConstellationType(i))

                            // ════ قوة الإشارة (Carrier-to-Noise dBHz) ════
                            try {
                                val snr = status.getCn0DbHz(i)
                                if (snr > 0f && snr < 100f) {
                                    snrSum += snr
                                    snrCount++
                                }
                            } catch (_: Exception) { /* بعض الأجهزة ترمي */ }

                            // ════ كشف Multi-frequency GPS (L5 band ≈ 1176 MHz) ════
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                try {
                                    if (status.hasCarrierFrequencyHz(i)) {
                                        val freqHz = status.getCarrierFrequencyHz(i)
                                        if (freqHz in 1.164e9f..1.189e9f) {
                                            l5Detected = true
                                        }
                                    }
                                } catch (_: Exception) { }
                            }
                        }
                    }
                    satellitesUsed = used
                    hasL5 = l5Detected
                    constellations = constellationSet.toSet()
                    avgSnr = if (snrCount > 0) snrSum / snrCount else 0f

                    // أعد بث آخر fix مع تحديث المعلومات
                    lastFix?.let {
                        trySend(it.copy(
                            satellitesUsed = satellitesUsed,
                            satellitesVisible = satellitesVisible,
                            hasMultiFrequencyGps = hasL5,
                            constellations = constellations,
                            averageSnrDbHz = avgSnr
                        ))
                    }
                }
            }
        } else null

        // ───── عدّاد البحث ─────
        val searchTicker = object : Runnable {
            override fun run() {
                if (bestLocation == null) {
                    val elapsed = (SystemClock.elapsedRealtime() - startTime) / 1000
                    trySend(Update.Searching(elapsed, satellitesVisible, cached))
                    handler.postDelayed(this, 1000)
                }
            }
        }

        try {
            lm.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000L, 0f,
                locListener, Looper.getMainLooper()
            )
            if (gnssCallback != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                lm.registerGnssStatusCallback(gnssCallback, handler)
            }

            // ════ API الحديث: fix فوري على Android 11+ ════
            // يحاول الحصول على fix جديد فوراً (ليس مجرد آخر معروف)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val cancelSignal = android.os.CancellationSignal()
                    lm.getCurrentLocation(
                        LocationManager.GPS_PROVIDER,
                        cancelSignal,
                        androidx.core.content.ContextCompat.getMainExecutor(context)
                    ) { loc ->
                        if (loc != null && loc.isValid() && !loc.isMockProvider()) {
                            if (bestLocation == null) {
                                bestLocation = loc
                                lastAcceptedRaw = loc
                                publishKalmanFix(loc)
                            }
                        }
                    }
                } catch (_: Exception) { /* fallback لـ requestLocationUpdates */ }
            }

            // fallback: آخر موقع معروف من النظام
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)?.let { last ->
                if (last.isValid() && last.isRecent() && !last.isMockProvider()) {
                    if (bestLocation == null) {
                        bestLocation = last
                        lastAcceptedRaw = last
                        publishKalmanFix(last)
                    }
                }
            }

            handler.post(searchTicker)
        } catch (e: SecurityException) {
            trySend(Update.NoPermission)
            close()
            return@callbackFlow
        }

        awaitClose {
            try { lm.removeUpdates(locListener) } catch (_: Exception) {}
            if (gnssCallback != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                try { lm.unregisterGnssStatusCallback(gnssCallback) } catch (_: Exception) {}
            }
            handler.removeCallbacksAndMessages(null)
        }
    }

    // ───── المساعدات ─────

    private fun qualityOf(accuracyM: Float): Quality = when {
        accuracyM <= 5f -> Quality.EXCELLENT
        accuracyM <= 10f -> Quality.VERY_GOOD
        accuracyM <= 20f -> Quality.GOOD
        accuracyM <= 50f -> Quality.ACCEPTABLE
        else -> Quality.POOR
    }

    /** فحص القفزات المستحيلة (سيارة سريعة الحد الأقصى ~360 كم/س) */
    private fun isImpossibleJump(prev: Location, current: Location): Boolean {
        val distM = prev.distanceTo(current)
        val timeDeltaSec = (current.time - prev.time).toFloat() / 1000f
        if (timeDeltaSec <= 0) return false
        if (distM < 100f) return false  // المسافات القصيرة ضمن طبيعي

        val impliedSpeed = distM / timeDeltaSec  // م/ث
        val MAX_REASONABLE_SPEED = 100f  // م/ث = 360 كم/س

        // قفزة مستحيلة + الإحداثية الجديدة تبدو دقيقة كذباً
        return impliedSpeed > MAX_REASONABLE_SPEED && current.accuracy < 50f
    }

    private fun Location.isValid(): Boolean {
        if (latitude.isNaN() || longitude.isNaN()) return false
        if (latitude < -90.0 || latitude > 90.0) return false
        if (longitude < -180.0 || longitude > 180.0) return false
        if (latitude == 0.0 && longitude == 0.0) return false
        if (accuracy <= 0f || accuracy > 5000f) return false
        return true
    }

    /** كشف المواقع الوهمية - يستخدم API الحديث على Android 12+ */
    private fun Location.isMockProvider(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            isMock
        } else {
            @Suppress("DEPRECATION")
            isFromMockProvider
        }
    }

    /**
     * مؤشر شامل لجودة fix من ٠ إلى ١٠٠.
     * يدمج: الدقة، عدد الأقمار، L5 (multi-freq)، عمر الـ fix.
     */
    private fun computeReliabilityScore(
        accuracyM: Float,
        satellitesUsed: Int,
        hasL5: Boolean,
        fixAgeMs: Long
    ): Int {
        var score = 100

        // عقوبة الدقة
        score -= when {
            accuracyM <= 5f -> 0
            accuracyM <= 10f -> 10
            accuracyM <= 20f -> 25
            accuracyM <= 50f -> 50
            else -> 80
        }

        // عقوبة الأقمار
        score -= when {
            satellitesUsed >= 8 -> 0
            satellitesUsed >= 5 -> 5
            satellitesUsed >= 4 -> 15
            satellitesUsed >= 1 -> 30
            else -> 0  // لا أقمار = api ربما لا يدعم
        }

        // مكافأة L5 (multi-frequency)
        if (hasL5) score += 10

        // عقوبة عمر fix
        when {
            fixAgeMs > 30_000 -> score -= 30
            fixAgeMs > 5_000 -> score -= 10
        }

        return score.coerceIn(0, 100)
    }

    private fun Location.isRecent(): Boolean {
        val ageMs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            (SystemClock.elapsedRealtimeNanos() - elapsedRealtimeNanos) / 1_000_000
        } else {
            System.currentTimeMillis() - time
        }
        return ageMs < 60_000
    }
}
