package com.qibla.compass

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Vibrator
import android.os.VibratorManager
import android.os.VibrationEffect
import android.provider.Settings
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.qibla.compass.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sensorManager: SensorManager
    private var rotationVector: Sensor? = null
    private var accelerometer: Sensor? = null
    private var magnetometer: Sensor? = null
    private var gyroscope: Sensor? = null
    private var linearAccelSensor: Sensor? = null  // accelerometer بدون جاذبية
    private var gravitySensor: Sensor? = null  // الجاذبية فقط (منعَّمة)

    private lateinit var locationFetcher: LocationFetcher
    private lateinit var prefs: Preferences
    private val stationaryAverager = StationaryAverager(maxSamples = 30)
    private var locationJob: Job? = null
    private var userLocation: Location? = null

    // قراءات الحساسات
    private val accelReading = FloatArray(3)
    private val magnetReading = FloatArray(3)
    private val gyroReading = FloatArray(3)
    private val linearAccelReading = FloatArray(3)  // accelerometer بدون جاذبية
    private val gravityReading = FloatArray(3)  // الجاذبية المنعَّمة
    private var hasFaceDown: Boolean = false  // الجهاز معكوس (شاشة لأسفل)
    private val rotationMatrix = FloatArray(9)
    private val smoothedMatrix = FloatArray(9)
    private val remappedMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)
    private var matrixInitialized = false

    // كشف الذكاء التكيّفي
    private var magneticFieldStrength = 0f
    private var hasMagneticInterference = false
    private var hasMagneticVariance = false  // تشويش زمني (ضوضاء)
    private var isStationary = false
    private var stillnessStreakStart: Long = 0L
    private var lastInterferenceCheckMs = 0L

    // نافذة منزلقة لقراءات شدة المجال (للكشف عن ضوضاء زمنية)
    private val magStrengthWindow = ArrayDeque<Float>()
    private val MAG_WINDOW_SIZE = 20  // ~10 ثوان عند SENSOR_DELAY_NORMAL
    private val MAG_VARIANCE_THRESHOLD = 4f  // μT - σ أكبر من ٤ = اضطراب

    // كاش الانحراف المغناطيسي + شدة المجال المتوقعة (WMM model)
    private var cachedDeclination: Float = 0f
    private var cachedExpectedFieldUT: Float = 0f  // ميكروتسلا المتوقعة للموقع
    private var lastDeclinationLat: Double = Double.NaN
    private var lastDeclinationLon: Double = Double.NaN

    // كشف ميل الهاتف الزائد
    private var devicePitchDeg: Float = 0f
    private var hasExcessiveTilt: Boolean = false

    // تقليل redraws للتغييرات الصغيرة جداً
    private var lastPushedAzimuth: Float = -999f
    private val AZIMUTH_PUSH_THRESHOLD = 0.05f  // درجة

    private var displayRotation = Surface.ROTATION_0
    private var selectedLocation = HolyLocations.KAABA
    private var qiblaBearing = 0.0
    private var distanceKm = 0.0

    private var lastVibrationTime = 0L
    private var wasLocked = false

    private val LOC_PERM_CODE = 4521
    private val MAGNETIC_NORMAL_MIN = 25f  // μT - الحد الأدنى الطبيعي
    private val MAGNETIC_NORMAL_MAX = 65f  // μT - الحد الأعلى الطبيعي
    private val GYRO_STATIONARY_THRESHOLD = 0.05f  // rad/s
    private val LINEAR_ACCEL_STATIONARY_THRESHOLD = 0.15f  // m/s² (بدون الجاذبية)

    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash Screen API - يعرض شاشة افتتاحية رسمية
        // يجب استدعاؤها قبل super.onCreate
        installSplashScreen()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefs = Preferences(this)

        setupSpinner()
        showHijriDate()
        cacheDisplayRotation()

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        // ترتيب الأولوية للحصول على أعلى دقة:
        // 1. ROTATION_VECTOR (gyro+accel+mag) - الأدق
        // 2. GEOMAGNETIC_ROTATION_VECTOR (accel+mag) - أقل بطارية، بدون gyro
        // 3. accel + mag يدوي
        rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        // Linear acceleration: accelerometer بدون الجاذبية
        linearAccelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        // Gravity: الجاذبية المنعَّمة (أدق من accelerometer للميل/الاتجاه)
        gravitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)

        locationFetcher = LocationFetcher(this)

        // ───── البداية الذكية: استخدم آخر موقع محفوظ فوراً ─────
        prefs.loadLocation()?.let { saved ->
            if (saved.ageHours < 24.0) {
                val cachedLoc = Location("cached").apply {
                    latitude = saved.latitude
                    longitude = saved.longitude
                    if (saved.altitude != 0.0) altitude = saved.altitude
                    accuracy = saved.accuracy
                }
                userLocation = cachedLoc
                binding.compassView.hasFix = true
                updateLocationCoords(cachedLoc)
                recomputeBearing()
                binding.statusText.text = String.format(
                    Locale.US,
                    "📍 موقع محفوظ (عمر %.1f ساعة) - في انتظار GPS...",
                    saved.ageHours
                )
                binding.statusText.setTextColor(0xFFD4AF37.toInt())
            }
        }

        // ───── استرجاع آخر مزار مختار ─────
        val savedTargetId = prefs.selectedTargetId
        val savedLoc = HolyLocations.ALL.firstOrNull { it.id == savedTargetId }
            ?: HolyLocations.KAABA
        selectedLocation = savedLoc
        val savedIndex = HolyLocations.ALL.indexOf(savedLoc)
        if (savedIndex >= 0) {
            binding.locationSpinner.setSelection(savedIndex)
        }
        // اعرض التسليم فوراً (في حالة الافتراضي، onItemSelected قد لا يُطلق)
        binding.compassView.targetLabel = if (savedLoc.isPrimary)
            "القبلة" else shortLabel(savedLoc.nameAr)
        showSalutation(savedLoc.id)

        // زر نسخ التسليم
        binding.copyBtn.setOnClickListener { copySalutationToClipboard() }
        binding.ziyaraBtn.setOnClickListener { showZiyaraDialog() }

        // ضغط طويل على البوصلة لعرض المعلومات التفصيلية
        binding.compassView.setOnLongClickListener {
            showDetailsDialog()
            true
        }

        ensureLocationPermission()
    }

    private fun cacheDisplayRotation() {
        displayRotation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay.rotation
        }
    }

    private fun setupSpinner() {
        val names = HolyLocations.ALL.map { it.nameAr }
        val adapter = ArrayAdapter(this, R.layout.spinner_item, names)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        binding.locationSpinner.adapter = adapter
        binding.locationSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                selectedLocation = HolyLocations.ALL[position]
                prefs.selectedTargetId = selectedLocation.id
                binding.compassView.targetLabel = if (selectedLocation.isPrimary)
                    "القبلة" else shortLabel(selectedLocation.nameAr)
                showSalutation(selectedLocation.id)
                recomputeBearing()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun shortLabel(full: String): String = when {
        full.contains("النبي") -> "النبي ﷺ"
        full.contains("فاطمة الزهراء") -> "الزهراء (ع)"
        full.contains("علي بن أبي") -> "الإمام علي"
        full.contains("الحسن المجتبى") -> "الحسن (ع)"
        full.contains("الحسين") -> "الحسين (ع)"
        full.contains("العباس") -> "العباس (ع)"
        full.contains("السجاد") -> "السجاد (ع)"
        full.contains("الباقر") -> "الباقر (ع)"
        full.contains("الصادق") -> "الصادق (ع)"
        full.contains("الكاظم") -> "الكاظم (ع)"
        full.contains("الرضا") -> "الرضا (ع)"
        full.contains("الجواد") -> "الجواد (ع)"
        full.contains("الهادي") -> "الهادي (ع)"
        full.contains("العسكري") -> "العسكري (ع)"
        full.contains("المهدي") -> "المهدي (عج)"
        full.contains("زينب") -> "زينب (ع)"
        full.contains("رقية") -> "رقية (ع)"
        full.contains("المعصومة") -> "المعصومة (ع)"
        full.contains("عبد العظيم") -> "عبد العظيم"
        else -> full.take(12)
    }

    private fun showHijriDate() {
        val cal = Calendar.getInstance()
        binding.hijriText.text = HijriDate.formatAr(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    // ═════════════ تدفق الإذن ═════════════

    private fun ensureLocationPermission() {
        val fine = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (fine) {
            startLocationCollection()
        } else {
            showPermissionRationaleDialog()
        }
    }

    private fun showPermissionRationaleDialog() {
        val showRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        )
        AlertDialog.Builder(this)
            .setTitle("🕋 إذن الموقع الدقيق")
            .setMessage(
                "لتحديد اتجاه القبلة بدقة عالية، يحتاج التطبيق GPS فقط.\n\n" +
                "🔒 موقعك لا يُرسل لأي خادم\n" +
                "📡 الحسابات محلية ١٠٠٪\n" +
                "🚫 التطبيق لا يستخدم الإنترنت\n" +
                "🛰 GPS فقط (لا Wi-Fi ولا شبكة)\n\n" +
                if (showRationale) "الرجاء منح الإذن \"الدقيق\"."
                else "اختر \"السماح أثناء استخدام التطبيق\"."
            )
            .setPositiveButton("منح الإذن") { _, _ ->
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ),
                    LOC_PERM_CODE
                )
            }
            .setCancelable(false)
            .show()
    }

    private fun showGpsDisabledDialog() {
        AlertDialog.Builder(this)
            .setTitle("📡 GPS مطفأ")
            .setMessage("خدمة GPS غير مفعّلة. التطبيق يستخدم GPS فقط (بدون شبكة).")
            .setPositiveButton("فتح إعدادات الموقع") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                } catch (e: Exception) {
                    Toast.makeText(this, "تعذّر فتح الإعدادات", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle("❌ تم رفض الإذن")
            .setMessage("بدون إذن الموقع، لا يمكن تحديد اتجاه القبلة بدقة.")
            .setPositiveButton("فتح الإعدادات") { _, _ -> openAppSettings() }
            .setNegativeButton("إغلاق") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun openAppSettings() {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            }
            startActivity(intent)
        } catch (e: Exception) { /* تجاهل */ }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != LOC_PERM_CODE) return
        val granted = grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        if (granted) startLocationCollection()
        else showPermissionDeniedDialog()
    }

    // ═════════════ جمع الموقع ═════════════

    private fun startLocationCollection() {
        locationJob?.cancel()
        locationJob = lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                locationFetcher.updates().collect { update ->
                    handleLocationUpdate(update)
                }
            }
        }
    }

    private fun handleLocationUpdate(update: LocationFetcher.Update) {
        when (update) {
            is LocationFetcher.Update.Fix -> {
                // إذا الجهاز ثابت ووصلتنا قراءة GPS حقيقية، نجمع للحصول على دقة فائقة
                val finalLocation: Location
                var averagedSamples = 0

                if (isStationary && !update.isFromCache) {
                    stationaryAverager.add(update.location)
                    val avg = stationaryAverager.computeWeightedMean()
                    if (avg != null) {
                        // استخدم المتوسط - دقة أعلى بكثير من القراءة الفردية
                        finalLocation = Location(update.location).apply {
                            latitude = avg.latitude
                            longitude = avg.longitude
                            accuracy = avg.accuracyM
                        }
                        averagedSamples = avg.sampleCount
                    } else {
                        // لم تكفي العينات بعد، استخدم الخام
                        finalLocation = update.location
                    }
                } else {
                    // الجهاز يتحرك أو من الكاش - فرّغ الـ averager
                    if (!update.isFromCache) stationaryAverager.reset()
                    finalLocation = update.location
                }

                userLocation = finalLocation
                updateDeclinationCache()
                binding.compassView.hasFix = true
                updateLocationCoords(finalLocation)
                renderQuality(update, averagedSamples)
                recomputeBearing()
            }
            is LocationFetcher.Update.Searching -> {
                if (userLocation == null) binding.compassView.hasFix = false
                renderSearching(update)
            }
            LocationFetcher.Update.GpsDisabled -> {
                stationaryAverager.reset()
                binding.statusText.text = "❌ GPS مطفأ - فعّله من الإعدادات"
                binding.statusText.setTextColor(0xFFFF5252.toInt())
                binding.satellitesText.text = ""
                showGpsDisabledDialog()
            }
            LocationFetcher.Update.NoPermission -> {
                stationaryAverager.reset()
                binding.statusText.text = "❌ الإذن مرفوض"
                binding.statusText.setTextColor(0xFFFF5252.toInt())
            }
            LocationFetcher.Update.MockLocationDetected -> {
                stationaryAverager.reset()
                binding.statusText.text = "🛡 رُفض موقع وهمي - عطّل تطبيقات تزييف الموقع"
                binding.statusText.setTextColor(0xFFFF5252.toInt())
            }
        }
    }

    private fun renderQuality(fix: LocationFetcher.Update.Fix, averagedSamples: Int = 0) {
        if (fix.isFromCache) {
            binding.accuracyBar.progress = 0
            return
        }

        // الدقة الفعّالة: إذا averaging مفعّل، نستخدم نتيجته
        val displayedAcc = if (averagedSamples >= 3) {
            // الـ averager أعطى دقة أعلى - مكتسبة من sqrt(N)
            val effAcc = fix.effectiveAccuracyM / kotlin.math.sqrt(averagedSamples.toFloat())
            effAcc.coerceAtMost(fix.effectiveAccuracyM)
        } else fix.effectiveAccuracyM

        val quality = when {
            displayedAcc <= 5f -> LocationFetcher.Quality.EXCELLENT
            displayedAcc <= 10f -> LocationFetcher.Quality.VERY_GOOD
            displayedAcc <= 20f -> LocationFetcher.Quality.GOOD
            displayedAcc <= 50f -> LocationFetcher.Quality.ACCEPTABLE
            else -> LocationFetcher.Quality.POOR
        }
        val (_, color) = when (quality) {
            LocationFetcher.Quality.EXCELLENT -> "ممتاز" to 0xFF00C853.toInt()
            LocationFetcher.Quality.VERY_GOOD -> "جيد جداً" to 0xFF00C853.toInt()
            LocationFetcher.Quality.GOOD -> "جيد" to 0xFF8BC34A.toInt()
            LocationFetcher.Quality.ACCEPTABLE -> "مقبول" to 0xFFFFC107.toInt()
            LocationFetcher.Quality.POOR -> "ضعيف" to 0xFFFF5252.toInt()
        }

        val accStr = when {
            averagedSamples >= 3 ->
                "≈${displayedAcc.toInt()}م (متوسط ${averagedSamples} قراءة)"
            fix.effectiveAccuracyM < fix.rawAccuracyM ->
                "${fix.effectiveAccuracyM.toInt()}م (Kalman: ${fix.rawAccuracyM.toInt()}م خام)"
            else -> "${fix.effectiveAccuracyM.toInt()}م"
        }

        // درجة الموثوقية الشاملة (0-100)
        val reliability = if (averagedSamples >= 3) {
            // عند averaging، نزيد الموثوقية حسب عدد العينات
            (fix.reliabilityScore + averagedSamples / 3).coerceIn(0, 100)
        } else fix.reliabilityScore

        binding.statusText.text = "✓ GPS • $accStr • موثوقية ${reliability}%"
        binding.statusText.setTextColor(color)

        // الشريط البصري
        val accForBar = displayedAcc.coerceIn(0f, 50f)
        val progress = ((1f - accForBar / 50f) * 100f).toInt()
        binding.accuracyBar.progress = progress
        binding.accuracyBar.progressTintList =
            android.content.res.ColorStateList.valueOf(color)

        if (fix.satellitesVisible > 0) {
            val l5Badge = if (fix.hasMultiFrequencyGps) " • L5 ⭐" else ""
            binding.satellitesText.text =
                "🛰 الأقمار: ${fix.satellitesUsed}/${fix.satellitesVisible} مستخدم$l5Badge"
            binding.satellitesText.setTextColor(
                when {
                    fix.hasMultiFrequencyGps -> 0xFF00C853.toInt()
                    fix.satellitesUsed >= 4 -> 0xFF00C853.toInt()
                    else -> 0xFFFFC107.toInt()
                }
            )

            // عرض الكوكبات + SNR كمعلومة إضافية
            if (fix.constellations.isNotEmpty() && fix.averageSnrDbHz > 0f) {
                val constNames = fix.constellations
                    .mapNotNull { constellationName(it) }
                    .joinToString("+")
                val snrLabel = when {
                    fix.averageSnrDbHz >= 40f -> "ممتاز"
                    fix.averageSnrDbHz >= 30f -> "جيد"
                    fix.averageSnrDbHz >= 20f -> "ضعيف"
                    else -> "ضعيف جداً"
                }
                binding.coordsText.text = String.format(
                    Locale.US,
                    "%.6f°, %.6f°  •  📡 %s  •  SNR %.0f ($snrLabel)",
                    fix.location.latitude, fix.location.longitude,
                    constNames, fix.averageSnrDbHz
                )
            }
        }
    }

    /** اسم الكوكبة من ثابت Android */
    private fun constellationName(type: Int): String? = when (type) {
        1 -> "GPS"          // CONSTELLATION_GPS
        2 -> null           // CONSTELLATION_SBAS (احتياطي)
        3 -> "GLONASS"      // CONSTELLATION_GLONASS
        4 -> "QZSS"         // CONSTELLATION_QZSS
        5 -> "BeiDou"       // CONSTELLATION_BEIDOU
        6 -> "Galileo"      // CONSTELLATION_GALILEO
        7 -> "IRNSS"        // CONSTELLATION_IRNSS
        else -> null
    }

    private fun renderSearching(s: LocationFetcher.Update.Searching) {
        // إذا عندنا cache، اعرض رسالة "في انتظار" لكن أبقِ الـ fix
        if (s.cachedLocation != null && userLocation?.provider == "cached") {
            binding.statusText.text = "🛰 في انتظار GPS... استخدام موقع محفوظ"
            binding.statusText.setTextColor(0xFFD4AF37.toInt())
            binding.satellitesText.text = if (s.satellitesVisible > 0)
                "🛰 الأقمار المرئية: ${s.satellitesVisible}" else ""
            return
        }

        val msg = when {
            s.elapsedSec < 5 -> "🛰 في انتظار GPS... (${s.elapsedSec} ث)"
            s.elapsedSec < 15 -> "🛰 جاري البحث عن أقمار صناعية... (${s.elapsedSec} ث)"
            s.elapsedSec < 30 -> "🛰 الحصول على إشارة قد يستغرق وقتاً تحت السقف..."
            s.elapsedSec < 60 -> "⚠ ضع الجهاز قرب نافذة أو في مكان مفتوح"
            else -> "⚠ تأكد من تفعيل GPS واخرج لمكان مفتوح"
        }
        val color = if (s.elapsedSec < 30) 0xFFFFC107.toInt() else 0xFFFF5252.toInt()
        binding.statusText.text = msg
        binding.statusText.setTextColor(color)
        binding.satellitesText.text = if (s.satellitesVisible > 0)
            "🛰 الأقمار المرئية: ${s.satellitesVisible}" else ""
    }

    private fun updateLocationCoords(loc: Location) {
        val coords = String.format(Locale.US, "%.6f°, %.6f°", loc.latitude, loc.longitude)
        val parts = mutableListOf(coords)

        if (loc.hasAltitude() && loc.altitude != 0.0) {
            parts.add(String.format(Locale.US, "ارتفاع: %.0fم", loc.altitude))
        }

        // عرض السرعة إذا متاحة (m/s → km/h)
        if (loc.hasSpeed() && loc.speed > 0.5f) {  // تجاهل الجلوس (ضوضاء GPS)
            val kmh = loc.speed * 3.6f
            parts.add(String.format(Locale.US, "السرعة: %.0f كم/س", kmh))
        }

        binding.coordsText.text = parts.joinToString(" • ")
    }

    // ═════════════ الحسابات ═════════════

    private fun recomputeBearing() {
        val loc = userLocation ?: return
        qiblaBearing = QiblaCalculator.bearingTo(
            loc.latitude, loc.longitude,
            selectedLocation.latitude, selectedLocation.longitude
        )
        distanceKm = QiblaCalculator.distanceKm(
            loc.latitude, loc.longitude,
            selectedLocation.latitude, selectedLocation.longitude
        )
        binding.compassView.targetBearing = qiblaBearing.toFloat()
        binding.bearingText.text = String.format(
            Locale.US, "%.2f°  •  %s",
            qiblaBearing, QiblaCalculator.cardinalAr(qiblaBearing)
        )
        binding.bearingDmsText.text = QiblaCalculator.formatDMS(qiblaBearing)
        binding.distanceText.text = QiblaCalculator.formatDistance(distanceKm)
    }

    // ═════════════ التسليم ═════════════

    private fun showSalutation(locationId: String) {
        val sal = Salutations.forId(locationId)
        if (sal == null) {
            binding.salutationCard.visibility = View.GONE
            return
        }
        binding.salutationCard.visibility = View.VISIBLE
        binding.salutationTitle.text = sal.title
        binding.salutationText.text = sal.text
    }

    private fun copySalutationToClipboard() {
        val sal = Salutations.forId(selectedLocation.id) ?: return
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(sal.title, sal.text)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "✓ تم نسخ التسليم", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذّر النسخ", Toast.LENGTH_SHORT).show()
        }
    }

    // ═════════════ الزيارة ═════════════

    private fun showZiyaraDialog() {
        val z = Ziyarat.forId(selectedLocation.id)
        if (z == null) {
            Toast.makeText(
                this,
                "لا توجد زيارة متاحة لهذا الاختيار",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val view = layoutInflater.inflate(R.layout.dialog_ziyara, null)
        val titleView = view.findViewById<TextView>(R.id.ziyaraTitle)
        val sourceView = view.findViewById<TextView>(R.id.ziyaraSource)
        val textView = view.findViewById<TextView>(R.id.ziyaraText)
        val copyBtn = view.findViewById<android.widget.Button>(R.id.ziyaraCopyBtn)
        val closeBtn = view.findViewById<android.widget.Button>(R.id.ziyaraCloseBtn)

        titleView.text = z.title
        sourceView.text = z.source
        textView.text = z.text

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .setCancelable(true)
            .create()

        copyBtn.setOnClickListener { copyZiyaraToClipboard(z) }
        closeBtn.setOnClickListener { dialog.dismiss() }

        dialog.show()

        // اضبط حجم الـ dialog ليكون أكبر (90% من الشاشة)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.95).toInt(),
            (resources.displayMetrics.heightPixels * 0.85).toInt()
        )
    }

    private fun copyZiyaraToClipboard(z: Ziyarat.Ziyara) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val full = "${z.title}\n${z.source}\n\n${z.text}"
            val clip = ClipData.newPlainText(z.title, full)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "✓ تم نسخ الزيارة", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذّر النسخ", Toast.LENGTH_SHORT).show()
        }
    }

    // ═════════════ معلومات تفصيلية (long-press) ═════════════

    private fun showDetailsDialog() {
        val loc = userLocation
        val angleDiff = if (loc != null) {
            kotlin.math.abs(QiblaCalculator.shortestAngleDiff(
                binding.compassView.targetAzimuth.toDouble(),
                qiblaBearing
            ))
        } else null

        val sb = StringBuilder()
        sb.append("📍 الموقع\n")
        if (loc != null) {
            sb.append(String.format(Locale.US,
                "خط العرض:  %.6f°\n", loc.latitude))
            sb.append(String.format(Locale.US,
                "خط الطول:  %.6f°\n", loc.longitude))
            if (loc.hasAltitude() && loc.altitude != 0.0)
                sb.append(String.format(Locale.US, "الارتفاع:  %.1f م\n", loc.altitude))
            if (loc.accuracy > 0)
                sb.append(String.format(Locale.US, "دقة GPS:  ±%.0f م\n", loc.accuracy))
            sb.append("المصدر:  ${loc.provider ?: "—"}\n")
        } else {
            sb.append("لا يوجد موقع بعد\n")
        }

        sb.append("\n🧭 الاتجاه\n")
        sb.append(String.format(Locale.US,
            "الزاوية للقبلة:  %.3f°\n", qiblaBearing))
        sb.append("DMS:  ${QiblaCalculator.formatDMS(qiblaBearing)}\n")
        sb.append("الجهة:  ${QiblaCalculator.cardinalAr(qiblaBearing)}\n")
        sb.append(String.format(Locale.US,
            "اتجاه الجهاز:  %.2f°\n", binding.compassView.targetAzimuth))
        if (angleDiff != null) {
            sb.append(String.format(Locale.US,
                "الفرق عن القبلة:  %.2f°\n", angleDiff))
        }

        sb.append("\n🌍 المعلومات الجيومغناطيسية\n")
        sb.append(String.format(Locale.US,
            "الانحراف المغناطيسي:  %.2f°\n", cachedDeclination))
        sb.append(String.format(Locale.US,
            "شدة المجال:  %.1f μT\n", magneticFieldStrength))

        sb.append("\n📐 وضعية الجهاز\n")
        sb.append(String.format(Locale.US,
            "الميل (pitch):  %.1f°\n", devicePitchDeg))
        sb.append("الجهاز ${if (isStationary) "ثابت ✓" else "متحرّك"}\n")

        sb.append("\n🎯 الهدف\n")
        sb.append("الموقع: ${selectedLocation.nameAr}\n")
        sb.append("المدينة: ${selectedLocation.cityAr}\n")
        sb.append(String.format(Locale.US,
            "إحداثيات: %.6f°, %.6f°\n",
            selectedLocation.latitude, selectedLocation.longitude))
        sb.append("المسافة: ${QiblaCalculator.formatDistance(distanceKm)}\n")

        AlertDialog.Builder(this)
            .setTitle("ℹ️ معلومات تفصيلية")
            .setMessage(sb.toString())
            .setPositiveButton("نسخ") { _, _ ->
                try {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("معلومات", sb.toString()))
                    Toast.makeText(this, "✓ تم النسخ", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {}
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    // ═════════════ الحساسات الذكية ═════════════

    override fun onResume() {
        super.onResume()
        cacheDisplayRotation()

        // إعادة ضبط الحالات الانتقالية لتجنب مزج بيانات قديمة بعد العودة من الخلفية
        matrixInitialized = false
        lastPushedAzimuth = -999f
        stillnessStreakStart = 0L
        wasLocked = false

        // SENSOR_DELAY_FASTEST = أعلى تردد يدعمه الجهاز (عادة 100-200Hz)
        val rate = SensorManager.SENSOR_DELAY_FASTEST

        if (rotationVector != null) {
            sensorManager.registerListener(this, rotationVector, rate)
        } else {
            accelerometer?.let { sensorManager.registerListener(this, it, rate) }
            magnetometer?.let { sensorManager.registerListener(this, it, rate) }
        }

        // المغنطومتر دائماً مطلوب لكشف التشويش
        if (rotationVector != null && magnetometer != null) {
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_NORMAL)
        }

        // gyroscope لكشف الجهاز الثابت
        gyroscope?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        // linear acceleration للكشف الأدق عن الثبات
        linearAccelSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
        // gravity للكشف الأدق عن الميل والاتجاه (شاشة لأسفل، إلخ)
        gravitySensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        try { sensorManager.unregisterListener(this) } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            locationJob?.cancel()
            sensorManager.unregisterListener(this)
        } catch (_: Exception) { /* تجاهل */ }
    }

    override fun onSensorChanged(event: SensorEvent) {
        try {
            when (event.sensor.type) {
                Sensor.TYPE_ROTATION_VECTOR,
                Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    applyMatrixSmoothing()
                    processRotation()
                }
                Sensor.TYPE_ACCELEROMETER -> {
                    System.arraycopy(event.values, 0, accelReading, 0, 3)
                    if (rotationVector == null) computeFromAccelMag()
                }
                Sensor.TYPE_MAGNETIC_FIELD -> {
                    System.arraycopy(event.values, 0, magnetReading, 0, 3)
                    checkMagneticInterference()
                    if (rotationVector == null) computeFromAccelMag()
                }
                Sensor.TYPE_GYROSCOPE -> {
                    System.arraycopy(event.values, 0, gyroReading, 0, 3)
                    checkStationary()
                }
                Sensor.TYPE_LINEAR_ACCELERATION -> {
                    System.arraycopy(event.values, 0, linearAccelReading, 0, 3)
                }
                Sensor.TYPE_GRAVITY -> {
                    System.arraycopy(event.values, 0, gravityReading, 0, 3)
                    checkFaceDown()
                }
            }
        } catch (e: Exception) {
            // حماية: قراءة حساس قد ترمي أحياناً (event.values قصير) - تجاهل بأمان
        }
    }

    /**
     * كشف التشويش المغناطيسي بناءً على شدة المجال.
     * المجال المغناطيسي للأرض الطبيعي: 25-65 μT
     * خارج هذا المدى = معادن قريبة، أجهزة كهربائية، إلخ
     */
    private fun checkMagneticInterference() {
        val now = System.currentTimeMillis()
        if (now - lastInterferenceCheckMs < 500) return
        lastInterferenceCheckMs = now

        val mx = magnetReading[0]
        val my = magnetReading[1]
        val mz = magnetReading[2]
        magneticFieldStrength = sqrt(mx * mx + my * my + mz * mz)

        // ════ ١. تشويش لحظي: مقارنة بالقيمة المتوقعة من نموذج WMM ════
        // الذكاء: إذا الموقع معروف، نستخدم القيمة المتوقعة لذلك الموقع المحدد
        // (مثلاً: العراق ≈ 45μT، النرويج ≈ 53μT، الإكوادور ≈ 30μT)
        // وإلا نقع على نطاق عام (25-65 μT)
        val newInterference = if (cachedExpectedFieldUT > 0f) {
            val tolerance = 15f  // μT - مقبول حول المتوقع
            magneticFieldStrength < (cachedExpectedFieldUT - tolerance) ||
            magneticFieldStrength > (cachedExpectedFieldUT + tolerance)
        } else {
            magneticFieldStrength < MAGNETIC_NORMAL_MIN ||
            magneticFieldStrength > MAGNETIC_NORMAL_MAX
        }

        // ════ ٢. تشويش زمني: تقلّب σ كبير في النافذة الزمنية ════
        magStrengthWindow.addLast(magneticFieldStrength)
        while (magStrengthWindow.size > MAG_WINDOW_SIZE) magStrengthWindow.removeFirst()

        val newVariance = if (magStrengthWindow.size >= MAG_WINDOW_SIZE / 2) {
            val mean = magStrengthWindow.average().toFloat()
            var sumSq = 0f
            for (v in magStrengthWindow) sumSq += (v - mean) * (v - mean)
            val sigma = sqrt(sumSq / magStrengthWindow.size)
            sigma > MAG_VARIANCE_THRESHOLD
        } else false

        if (newInterference != hasMagneticInterference || newVariance != hasMagneticVariance) {
            hasMagneticInterference = newInterference
            hasMagneticVariance = newVariance
            updateAccuracyText()
        }
    }

    /**
     * كشف الجهاز المعكوس (الشاشة لأسفل) عبر الجاذبية.
     * gravity[2] = z-axis component:
     *   +9.8 ≈ شاشة لأعلى (طبيعي)
     *   -9.8 ≈ شاشة لأسفل (معكوس)
     *   ~0 ≈ عمودي
     */
    private fun checkFaceDown() {
        val gz = gravityReading[2]
        // إذا z-component سالب وأكبر من نصف الجاذبية، الجهاز مقلوب
        val newFaceDown = gz < -5f
        if (newFaceDown != hasFaceDown) {
            hasFaceDown = newFaceDown
            updateAccuracyText()
        }
    }

    /**
     * كشف الجهاز الثابت بمؤشرين مدموجين:
     * - gyroscope: كشف الدوران (rotation)
     * - linear acceleration: كشف الحركة الانتقالية (translation)
     */
    private fun checkStationary() {
        // مقدار الدوران الزاوي
        val gyroMag = sqrt(
            gyroReading[0] * gyroReading[0] +
            gyroReading[1] * gyroReading[1] +
            gyroReading[2] * gyroReading[2]
        )
        // مقدار التسارع الخطي (بدون الجاذبية)
        val linearMag = sqrt(
            linearAccelReading[0] * linearAccelReading[0] +
            linearAccelReading[1] * linearAccelReading[1] +
            linearAccelReading[2] * linearAccelReading[2]
        )

        val now = System.currentTimeMillis()
        // كلاهما يجب أن يكون منخفضاً
        // (gyro < 0.05 rad/s) و (linear accel < 0.15 m/s²)
        val isReallyStill = gyroMag < GYRO_STATIONARY_THRESHOLD &&
                            linearMag < LINEAR_ACCEL_STATIONARY_THRESHOLD

        if (isReallyStill) {
            if (stillnessStreakStart == 0L) stillnessStreakStart = now
            val sustainedMs = now - stillnessStreakStart
            val newStationary = sustainedMs >= 1500L
            if (newStationary != isStationary) {
                isStationary = newStationary
                if (newStationary) stationaryAverager.reset()
                updateAccuracyText()
            }
        } else {
            stillnessStreakStart = 0L
            if (isStationary) {
                isStationary = false
                stationaryAverager.reset()
                updateAccuracyText()
            }
        }
    }

    /**
     * تنعيم على مستوى مصفوفة الدوران.
     * α تكيّفي: عند الثبات نزيد التنعيم، عند الحركة نقلّله.
     */
    private fun applyMatrixSmoothing() {
        // عند الثبات: α منخفض (تنعيم أعلى) للحصول على azimuth ثابت
        // عند الحركة: α عالٍ (استجابة سريعة)
        val alpha = if (isStationary) 0.15f else 0.4f

        if (!matrixInitialized) {
            System.arraycopy(rotationMatrix, 0, smoothedMatrix, 0, 9)
            matrixInitialized = true
        } else {
            for (i in 0 until 9) {
                smoothedMatrix[i] = smoothedMatrix[i] * (1f - alpha) + rotationMatrix[i] * alpha
            }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // تحديث دوران الشاشة عند تغيير الاتجاه (مهم للأجهزة اللوحية)
        cacheDisplayRotation()
        matrixInitialized = false  // أعد التهيئة لتجنب القفزات
    }

    private fun processRotation() {
        try {
            val (axisX, axisY) = when (displayRotation) {
                Surface.ROTATION_0 -> SensorManager.AXIS_X to SensorManager.AXIS_Y
                Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
            SensorManager.remapCoordinateSystem(smoothedMatrix, axisX, axisY, remappedMatrix)
            SensorManager.getOrientation(remappedMatrix, orientationAngles)

            val magneticAzimuth = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
            val pitchDeg = Math.toDegrees(orientationAngles[1].toDouble()).toFloat()
            val rollDeg = Math.toDegrees(orientationAngles[2].toDouble()).toFloat()

            // كشف الميل الزائد
            val tiltMagnitude = kotlin.math.max(
                kotlin.math.abs(pitchDeg),
                kotlin.math.abs(rollDeg)
            )
            val newExcessiveTilt = tiltMagnitude > 60f
            if (newExcessiveTilt != hasExcessiveTilt) {
                hasExcessiveTilt = newExcessiveTilt
                updateAccuracyText()
            }
            devicePitchDeg = pitchDeg

            updateAzimuth(magneticAzimuth)
        } catch (e: Exception) {
            // حماية من matrix غير صالح أو event.values قصير
        }
    }

    private fun computeFromAccelMag() {
        if (SensorManager.getRotationMatrix(rotationMatrix, null, accelReading, magnetReading)) {
            applyMatrixSmoothing()
            processRotation()
        }
    }

    private fun updateAzimuth(magneticAzimuth: Float) {
        val trueAzimuth = applyDeclination(magneticAzimuth)
        val normalized = ((trueAzimuth + 360f) % 360f)

        // Throttle: تجاهل التغييرات < 0.05° (تحت دقة الحساس)
        val diff = QiblaCalculator.shortestAngleDiff(
            lastPushedAzimuth.toDouble(), normalized.toDouble()
        ).toFloat()
        if (kotlin.math.abs(diff) < AZIMUTH_PUSH_THRESHOLD && lastPushedAzimuth >= 0f) {
            return
        }
        lastPushedAzimuth = normalized

        binding.compassView.targetAzimuth = normalized

        val nowLocked = binding.compassView.isLocked
        if (nowLocked && !wasLocked) {
            triggerLockedFeedback()  // اهتزاز قوي عند الوصول
        } else if (!nowLocked && wasLocked) {
            triggerUnlockFeedback()  // اهتزاز خفيف عند الفقدان
        }
        wasLocked = nowLocked
    }

    /**
     * تحديث الانحراف المغناطيسي + شدة المجال المتوقعة - عند تغيير الموقع فقط.
     * `GeomagneticField` (نموذج WMM) يعطي:
     * - الانحراف (declination): فرق الشمال المغناطيسي عن الجغرافي
     * - شدة المجال (fieldStrength) المتوقعة لهذا الموقع
     */
    private fun updateDeclinationCache() {
        val loc = userLocation ?: return
        if (!lastDeclinationLat.isNaN() &&
            kotlin.math.abs(loc.latitude - lastDeclinationLat) < 0.001 &&
            kotlin.math.abs(loc.longitude - lastDeclinationLon) < 0.001) return

        val gmf = GeomagneticField(
            loc.latitude.toFloat(),
            loc.longitude.toFloat(),
            if (loc.hasAltitude()) loc.altitude.toFloat() else 0f,
            System.currentTimeMillis()
        )
        cachedDeclination = gmf.declination
        cachedExpectedFieldUT = gmf.fieldStrength / 1000f  // nT → μT
        lastDeclinationLat = loc.latitude
        lastDeclinationLon = loc.longitude
    }

    private fun applyDeclination(magneticAzimuth: Float): Float {
        return magneticAzimuth + cachedDeclination
    }

    private fun triggerLockedFeedback() {
        // اهتزاز قوي عند الوصول للقبلة: ضربتان قصيرتان
        vibratePattern(longArrayOf(0, 50, 80, 50), throttleMs = 1000L)
    }

    private fun triggerUnlockFeedback() {
        // اهتزاز خفيف عند فقدان الـ lock: ضربة قصيرة واحدة
        vibratePattern(longArrayOf(0, 25), throttleMs = 600L)
    }

    private fun vibratePattern(pattern: LongArray, throttleMs: Long) {
        val now = System.currentTimeMillis()
        if (now - lastVibrationTime < throttleMs) return
        lastVibrationTime = now
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            if (vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(pattern, -1)
                }
            }
        } catch (_: Exception) { /* تجاهل */ }
    }

    private var lastSensorAccuracy: Int = SensorManager.SENSOR_STATUS_ACCURACY_HIGH

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor?.type != Sensor.TYPE_ROTATION_VECTOR &&
            sensor?.type != Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR &&
            sensor?.type != Sensor.TYPE_MAGNETIC_FIELD) return
        lastSensorAccuracy = accuracy
        updateAccuracyText()
    }

    /** يدمج رسائل دقة الحساس + كشف التشويش + كشف الميل */
    private fun updateAccuracyText() {
        val text: String
        val color: Int

        when {
            hasFaceDown -> {
                text = "⚠ الجهاز مقلوب - اقلبه بحيث الشاشة للأعلى"
                color = 0xFFFF9800.toInt()
            }
            hasExcessiveTilt -> {
                text = "⚠ الجهاز مائل - أمسك الهاتف بشكل أفقي للدقة"
                color = 0xFFFF9800.toInt()
            }
            hasMagneticInterference -> {
                text = String.format(
                    Locale.US,
                    "⚠ تشويش مغناطيسي (%.0fμT) - ابتعد عن المعادن",
                    magneticFieldStrength
                )
                color = 0xFFFF5252.toInt()
            }
            hasMagneticVariance -> {
                text = "⚠ تذبذب مغناطيسي - يوجد مصدر قريب يضطرب البوصلة"
                color = 0xFFFF9800.toInt()
            }
            lastSensorAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE -> {
                text = "⚠ بوصلة غير موثوقة - أعد المعايرة"
                color = 0xFFFF5252.toInt()
            }
            lastSensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW -> {
                text = "⚠ حرّك الجهاز على شكل ∞ للمعايرة"
                color = 0xFFFF5252.toInt()
            }
            lastSensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM -> {
                val stationaryBadge = if (isStationary) " • ثابت" else ""
                text = "⚡ بوصلة بدقة متوسطة$stationaryBadge"
                color = 0xFFFFC107.toInt()
            }
            lastSensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH -> {
                val stationaryBadge = if (isStationary) " • ثابت" else ""
                text = String.format(
                    Locale.US,
                    "✓ بوصلة دقيقة (%.0fμT)$stationaryBadge",
                    magneticFieldStrength
                )
                color = 0xFF00C853.toInt()
            }
            else -> { text = ""; color = 0xFF9E9E9E.toInt() }
        }
        binding.accuracyText.text = text
        binding.accuracyText.setTextColor(color)
    }
}
