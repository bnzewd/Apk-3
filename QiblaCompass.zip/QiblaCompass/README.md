# بوصلة القبلة الذكية v6.0 🕋

تطبيق Android لتحديد اتجاه القبلة والمزارات المقدسة.
**يعمل في أي مكان • بدون إنترنت • ذكي وتكيّفي.**

## ما يجعله "ذكياً"

### ١. Kalman Filter للموقع
خوارزمية إحصائية تدمج عدة قراءات GPS رياضياً للحصول على دقة أعلى من أي قراءة فردية. عند الوقوف ثابتاً، الفلتر يقلل الـ "drift" الطبيعي في GPS بمرور الوقت.

```
قراءة 1: ±15م → Kalman → ±15م
قراءة 2: ±12م → Kalman → ±10م (دمج ذكي)
قراءة 3: ±20م → Kalman → ±9م
قراءة N: → ±5م (مستقر)
```

### ٢. تخزين محلي للموقع (يعمل في أي مكان)
- يحفظ آخر موقع GPS صالح في `SharedPreferences`
- عند فتح التطبيق التالي، يستخدم الموقع المحفوظ **فوراً** للحساب
- في الخلفية، يحاول الحصول على GPS جديد
- يحدّث الحساب عند وصول GPS، ويحفظ الموقع الجديد

النتيجة: التطبيق يعمل **حتى قبل وصول GPS**، حتى لو كنت داخل بناية.

### ٣. تنعيم تكيّفي (Adaptive Smoothing)
- **حركة كبيرة** (>30°): استجابة سريعة (RESPONSIVENESS=18)
- **حركة صغيرة** (<2°): تنعيم عميق (RESPONSIVENESS=6)
- **تدرج خطي** بينهما

النتيجة: استجابة فورية لتدوير الجهاز + سلاسة كاملة عند الثبات.

### ٤. كشف التشويش المغناطيسي
المجال المغناطيسي للأرض الطبيعي: **25-65 μT**.
التطبيق يقيس شدة المجال (`√(mx² + my² + mz²)`) ويحذّر عند الخروج عن المدى:
- معادن قريبة (مفاتيح، حلي، سيارات)
- أجهزة كهربائية (مكبرات صوت، شواحن)
- مغناطيسات (في الأغلفة الذكية)

### ٥. كشف الجهاز الثابت
يستخدم gyroscope variance:
- إذا |ω| < 0.05 rad/s → الجهاز ثابت
- يزيد التنعيم تلقائياً للحصول على azimuth أكثر استقراراً
- يعرض مؤشّر "ثابت" في الواجهة

### ٦. حفظ آخر مزار مختار
عند تغيير المزار من spinner، يُحفظ. عند فتح التطبيق التالي، يستعيد آخر اختيار.

### ٧. تردد الحساس الأقصى
`SensorManager.SENSOR_DELAY_FASTEST` بدلاً من `SENSOR_DELAY_GAME`:
- **GAME**: ~50Hz
- **FASTEST**: ~100-200Hz (حسب الجهاز)

ضعف معدل التحديث = حركة أنعم وأكثر دقة.

### ٨. ترتيب أولوية الحساسات
1. `TYPE_ROTATION_VECTOR` (gyro+accel+mag) — الأدق
2. `TYPE_GEOMAGNETIC_ROTATION_VECTOR` (accel+mag) — أقل بطارية
3. `accel + mag` يدوي مع `getRotationMatrix`

التطبيق يستخدم الأفضل المتاح تلقائياً.

## دقة GPS العالية (٥ مستويات)

| الدقة | التقييم | اللون |
|---|---|---|
| ≤ 5م | ممتاز | 🟢 |
| ≤ 10م | جيد جداً | 🟢 |
| ≤ 20م | جيد | 🟢 |
| ≤ 50م | مقبول | 🟡 |
| > 50م | ضعيف | 🔴 |

عرض الدقة الفعّالة بعد Kalman:
```
✓ GPS • 8م (Kalman: 15م خام) (جيد جداً)
🛰 الأقمار: 9/13 مستخدم
```

## بدون إنترنت إطلاقاً

- ❌ لا `INTERNET` permission في الـ Manifest
- ❌ لا Network Provider (يحتاج Wi-Fi/خلوي)
- ❌ لا Wi-Fi positioning
- ❌ لا A-GPS (Assisted GPS)
- ❌ لا Google Play Services
- ✅ GPS Hardware فقط
- ✅ كل الحسابات محلية

## بنية المشروع

```
app/src/main/java/com/qibla/compass/
├── MainActivity.kt              # الواجهة + الذكاء التكيّفي
├── LocationFetcher.kt           # GPS + Kalman + GnssStatus → Flow<Update>
├── LocationKalmanFilter.kt      # فلتر Kalman 1D للإحداثيات
├── Preferences.kt               # تخزين محلي (آخر موقع + مزار)
├── CompassView.kt               # رسم البوصلة + adaptive smoothing
├── QiblaCalculator.kt           # Great Circle + Haversine
├── HolyLocations.kt             # ٢٠ موقعاً مقدساً
├── HijriDate.kt                 # التقويم الهجري
└── QiblaApp.kt                  # Application
```

## التقنيات المستخدمة (أحدث ما يقدمه Android)

| التقنية | الاستخدام |
|---|---|
| **Kotlin Coroutines + Flow** | تدفق تحديثات GPS |
| **`callbackFlow`** | تحويل callbacks إلى Flow |
| **`lifecycleScope` + `repeatOnLifecycle`** | إدارة دورة الحياة |
| **`GnssStatus.Callback`** (API 24+) | مراقبة الأقمار |
| **`ViewBinding`** | بدلاً من `findViewById` |
| **Matrix smoothing** | تجنب gimbal lock |
| **Frame-based animation** | مستقل عن معدل الحساس |

## البناء

### GitHub Actions (الأسهل)
`.github/workflows/build.yml` جاهز - ارفع المشروع → تاب Actions → نزّل APK.

### Kali Linux محلياً
```bash
unzip QiblaCompass.zip
cd QiblaCompass
bash build_apk.sh
```

### Android Studio
`File → Open` → اختر المجلد → Build → Build APK(s).

## التثبيت

```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

أو انسخ ملف الـ APK للهاتف، افتحه، اقبل التثبيت من مصادر مجهولة.

## المتطلبات

- Android 7.0+ (API 24)
- حساس مغناطيسي + accelerometer
- (اختياري) gyroscope - لكشف الثبات
- GPS hardware

## الترخيص
كود مفتوح للاستخدام الشخصي والتطوير.
