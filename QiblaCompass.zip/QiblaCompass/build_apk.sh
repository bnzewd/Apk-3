#!/usr/bin/env bash
# build_apk.sh - بناء APK تلقائياً على Kali Linux / Ubuntu
# الاستخدام:  bash build_apk.sh
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOLS_DIR="$HOME/.qibla-build"
SDK_DIR="$TOOLS_DIR/android-sdk"
GRADLE_DIR="$TOOLS_DIR/gradle-8.4"

CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
GRADLE_URL="https://services.gradle.org/distributions/gradle-8.4-bin.zip"

cd "$PROJECT_DIR"
mkdir -p "$TOOLS_DIR"

echo "════════════════════════════════════════════"
echo "   بناء بوصلة القبلة v19.0 - APK"
echo "════════════════════════════════════════════"

# ───────── 1) JDK 17 ─────────
need_jdk=1
if command -v java &>/dev/null; then
    if java -version 2>&1 | grep -qE '"(17|21)\.'; then need_jdk=0; fi
fi
if [ $need_jdk -eq 1 ]; then
    echo "[+] تثبيت JDK 17..."
    sudo apt-get update -qq
    sudo apt-get install -y openjdk-17-jdk unzip wget curl
fi
JAVA_BIN="$(readlink -f "$(which java)")"
export JAVA_HOME="${JAVA_BIN%/bin/java}"
echo "[✓] JAVA_HOME=$JAVA_HOME"

# ───────── 2) Android SDK ─────────
if [ ! -d "$SDK_DIR/cmdline-tools/latest/bin" ]; then
    echo "[+] تنزيل Android command-line tools..."
    mkdir -p "$SDK_DIR/cmdline-tools"
    cd /tmp
    [ -f cmdline-tools.zip ] || wget -q --show-progress -O cmdline-tools.zip "$CMDLINE_URL"
    rm -rf cmdline-tools
    unzip -q -o cmdline-tools.zip
    rm -rf "$SDK_DIR/cmdline-tools/latest"
    mv cmdline-tools "$SDK_DIR/cmdline-tools/latest"
    cd "$PROJECT_DIR"
fi

export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

echo "[+] قبول الرخص وتثبيت SDK packages..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager --install \
    "platform-tools" \
    "platforms;android-34" \
    "build-tools;34.0.0" 2>&1 | grep -v "^\[" || true

# ───────── 3) Gradle مستقل (لا يحتاج wrapper jar) ─────────
if [ ! -d "$GRADLE_DIR/bin" ]; then
    echo "[+] تنزيل Gradle 8.4..."
    cd /tmp
    [ -f gradle-8.4-bin.zip ] || wget -q --show-progress -O gradle-8.4-bin.zip "$GRADLE_URL"
    unzip -q -o gradle-8.4-bin.zip -d "$TOOLS_DIR"
    cd "$PROJECT_DIR"
fi
export PATH="$GRADLE_DIR/bin:$PATH"

# توليد gradle wrapper إذا غير موجود
if [ ! -f "gradlew" ] || [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "[+] توليد Gradle wrapper..."
    gradle wrapper --gradle-version 8.4 --distribution-type bin --quiet
fi
chmod +x gradlew

# ───────── 4) إنشاء local.properties ─────────
echo "sdk.dir=$SDK_DIR" > local.properties

# ───────── 5) البناء ─────────
echo ""
echo "[+] بناء APK (debug)..."
./gradlew assembleDebug --no-daemon

APK="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    SIZE=$(du -h "$APK" | cut -f1)
    echo ""
    echo "════════════════════════════════════════════"
    echo "   ✓ تم البناء بنجاح"
    echo "════════════════════════════════════════════"
    echo ""
    echo "   📦 ملف الـ APK:"
    echo "   $APK"
    echo "   📏 الحجم: $SIZE"
    echo ""
    echo "════════════════════════════════════════════"
    echo ""
    echo "للتثبيت على هاتف متصل بـ USB:"
    echo "   adb install \"$APK\""
    echo ""
    echo "أو انسخه إلى الهاتف وثبته يدوياً"
    echo "(فعّل: Settings → Security → Install unknown apps)"
    echo ""
else
    echo ""
    echo "════════════════════════════════════════════"
    echo "   ✗ فشل البناء"
    echo "════════════════════════════════════════════"
    echo "راجع المخرجات أعلاه للتفاصيل."
    exit 1
fi
